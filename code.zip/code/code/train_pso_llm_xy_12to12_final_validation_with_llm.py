#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_pso_llm_xy_12to12_final_validation.py

Final: PSO + LLM 主框架 + TCN validation-only predictor

目的：
  当前 v7/v8/v9 的 MLP/Embedding/GRU 残差校正整体 MAE 卡在 14.7 左右。
  v11 保留 PSO 候选预测与 LLM 主框架描述，但把数值预测主干升级为 TCN 时序残差模型。

核心逻辑：
  1. 仍使用客户要求的 PeMS03 12→12 数据逻辑：X=过去12步，Y=未来12步。
  2. 复用 v7 脚本中的 PSO 候选预测器，得到 pso_prediction。
  3. TCN 模型读取：历史12步、历史差分、PSO未来12步、sensor_id、time-of-day、day-of-week、future step。
  4. 模型输出未来12步 residual = Y - pso_prediction。
  5. 最终预测：final = pso_prediction + residual_scale * residual_pred。
  6. validation 用来选择 best residual_scale 和 best checkpoint，并作为模型性能汇报口径。

运行前要求：
  train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py 与本脚本在同一目录，或通过 --base_script 指定。

说明：
  本交付版不输出测试集指标，只输出 validation_metrics.json、validation_predictions.csv 与 prediction_examples.png。
"""

import argparse
import importlib.util
import json
import math
import random
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


SEQ_LEN = 12
PRED_LEN = 12
N_SENSOR = 358
DAY_STEPS = 288


def import_base(path: str):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"找不到 base 脚本: {path}")
    spec = importlib.util.spec_from_file_location("pso_llm_v7_base", str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def build_temporal_pairs(base, X, Y, index_df, raw, profile, train_end, particle,
                         max_pairs=50000, seed=42, batch_size=2000):
    """构造 TCN 训练/验证/测试所需数据。"""
    sample_ids, sensor_ids, target_start = base.sample_pairs(
        X, Y, index_df, max_pairs=max_pairs, seed=seed
    )
    time_w, cand_w = base.decode_particle(particle)

    hists, targets, pso_preds = [], [], []
    n = len(sample_ids)
    for st in tqdm(range(0, n, batch_size), desc="Building temporal pairs", leave=False):
        ed = min(st + batch_size, n)
        sid = sample_ids[st:ed]
        sen = sensor_ids[st:ed]
        ts = target_start[st:ed]

        hist, target = base.gather_xy(X, Y, sid, sen)
        candidates = base.build_candidates(
            hist, time_w, raw, ts, sen,
            profile=profile,
            train_end=train_end,
        )
        pso_pred = base.fuse_candidates(candidates, cand_w)

        hists.append(hist.astype(np.float32))
        targets.append(target.astype(np.float32))
        pso_preds.append(pso_pred.astype(np.float32))

    out = {
        "hist": np.concatenate(hists, axis=0).astype(np.float32),
        "target": np.concatenate(targets, axis=0).astype(np.float32),
        "pso": np.concatenate(pso_preds, axis=0).astype(np.float32),
        "sample_ids": sample_ids.astype(np.int64),
        "sensor_ids": sensor_ids.astype(np.int64),
        "target_start": target_start.astype(np.int64),
    }
    return out


class TemporalPairDataset(Dataset):
    def __init__(self, data, norm=None):
        self.hist = np.asarray(data["hist"], dtype=np.float32)
        self.target = np.asarray(data["target"], dtype=np.float32)
        self.pso = np.asarray(data["pso"], dtype=np.float32)
        self.sensor_ids = np.asarray(data["sensor_ids"], dtype=np.int64)
        self.target_start = np.asarray(data["target_start"], dtype=np.int64)

        residual = self.target - self.pso
        diff = np.diff(self.hist, prepend=self.hist[:, :1], axis=1).astype(np.float32)

        if norm is None:
            flow_values = np.concatenate([
                self.hist.reshape(-1),
                self.pso.reshape(-1),
                self.target.reshape(-1),
            ], axis=0)
            flow_mean = float(np.mean(flow_values))
            flow_std = float(np.std(flow_values) + 1e-6)
            flow_std = max(flow_std, 1.0)
            residual_scale = float(np.std(residual) + 1e-6)
            residual_scale = max(residual_scale, 1.0)
            norm = {
                "flow_mean": flow_mean,
                "flow_std": flow_std,
                "residual_scale": residual_scale,
            }

        self.norm = norm
        fm = norm["flow_mean"]
        fs = norm["flow_std"]
        rs = norm["residual_scale"]

        self.hist_norm = ((self.hist - fm) / fs).astype(np.float32)
        self.diff_norm = (diff / fs).astype(np.float32)
        self.pso_norm = ((self.pso - fm) / fs).astype(np.float32)
        self.residual_norm = (residual / rs).astype(np.float32)

        self.tod_ids = (self.target_start % DAY_STEPS).astype(np.int64)
        self.dow_ids = ((self.target_start // DAY_STEPS) % 7).astype(np.int64)

    def __len__(self):
        return self.hist.shape[0]

    def __getitem__(self, idx):
        return (
            torch.tensor(self.hist_norm[idx], dtype=torch.float32),
            torch.tensor(self.diff_norm[idx], dtype=torch.float32),
            torch.tensor(self.pso_norm[idx], dtype=torch.float32),
            torch.tensor(self.sensor_ids[idx], dtype=torch.long),
            torch.tensor(self.tod_ids[idx], dtype=torch.long),
            torch.tensor(self.dow_ids[idx], dtype=torch.long),
            torch.tensor(self.residual_norm[idx], dtype=torch.float32),
        )


class TCNBlock(nn.Module):
    def __init__(self, channels, kernel_size=3, dilation=1, dropout=0.1):
        super().__init__()
        pad = dilation * (kernel_size - 1) // 2
        self.net = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return x + self.net(x)


class TemporalTCNResidualNet(nn.Module):
    def __init__(self, hidden=256, dropout=0.1,
                 sensor_emb_dim=32, tod_emb_dim=16, dow_emb_dim=4, step_emb_dim=8):
        super().__init__()
        self.hidden = int(hidden)
        self.sensor_emb = nn.Embedding(N_SENSOR, sensor_emb_dim)
        self.tod_emb = nn.Embedding(DAY_STEPS, tod_emb_dim)
        self.dow_emb = nn.Embedding(7, dow_emb_dim)
        self.step_emb = nn.Embedding(PRED_LEN, step_emb_dim)
        self.future_tod_emb = nn.Embedding(DAY_STEPS, tod_emb_dim)

        self.in_proj = nn.Conv1d(2, hidden, kernel_size=1)
        self.tcn = nn.Sequential(
            TCNBlock(hidden, dilation=1, dropout=dropout),
            TCNBlock(hidden, dilation=2, dropout=dropout),
            TCNBlock(hidden, dilation=4, dropout=dropout),
        )
        self.context_norm = nn.LayerNorm(hidden)

        dec_in = hidden + 1 + sensor_emb_dim + tod_emb_dim + dow_emb_dim + step_emb_dim + tod_emb_dim
        self.decoder = nn.Sequential(
            nn.Linear(dec_in, hidden),
            nn.LayerNorm(hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, hist_norm, diff_norm, pso_norm, sensor_ids, tod_ids, dow_ids):
        # hist_norm / diff_norm / pso_norm: [B, 12]
        b = hist_norm.shape[0]
        x = torch.stack([hist_norm, diff_norm], dim=1)  # [B,2,12]
        z = self.in_proj(x)
        z = self.tcn(z)
        context = z.mean(dim=2) + z[:, :, -1]
        context = self.context_norm(context)

        step_ids = torch.arange(PRED_LEN, device=hist_norm.device, dtype=torch.long)
        step_e = self.step_emb(step_ids).unsqueeze(0).expand(b, -1, -1)

        sensor_e = self.sensor_emb(sensor_ids)
        tod_e = self.tod_emb(tod_ids)
        dow_e = self.dow_emb(dow_ids)
        node_time_e = torch.cat([sensor_e, tod_e, dow_e], dim=1).unsqueeze(1).expand(-1, PRED_LEN, -1)

        future_tod = (tod_ids.unsqueeze(1) + step_ids.unsqueeze(0)) % DAY_STEPS
        future_tod_e = self.future_tod_emb(future_tod)

        context_e = context.unsqueeze(1).expand(-1, PRED_LEN, -1)
        pso_e = pso_norm.unsqueeze(-1)

        dec = torch.cat([context_e, pso_e, node_time_e, step_e, future_tod_e], dim=2)
        out = self.decoder(dec).squeeze(-1)
        return out


def residual_loss(pred, target):
    mae = torch.mean(torch.abs(pred - target))
    smooth = nn.functional.smooth_l1_loss(pred, target, beta=0.5)
    step_mae = torch.mean(torch.abs(torch.mean(pred, dim=0) - torch.mean(target, dim=0)))
    return mae + 0.5 * smooth + 0.05 * step_mae


@torch.no_grad()
def predict_residual(model, ds: TemporalPairDataset, device, batch_size=4096):
    loader = DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=0)
    model.eval()
    outs = []
    for hist, diff, pso, sensor, tod, dow, _ in tqdm(loader, desc="Predict residual", leave=False):
        hist = hist.to(device)
        diff = diff.to(device)
        pso = pso.to(device)
        sensor = sensor.to(device)
        tod = tod.to(device)
        dow = dow.to(device)
        pred_norm = model(hist, diff, pso, sensor, tod, dow)
        pred = pred_norm.detach().cpu().numpy().astype(np.float32) * float(ds.norm["residual_scale"])
        outs.append(pred)
    return np.concatenate(outs, axis=0).astype(np.float32)


def tune_scale(base, target, pso, residual_pred, hist, scales):
    records = []
    best = None
    for s in scales:
        final = pso + float(s) * residual_pred
        final = base.clip_final_prediction(final, hist, pso)
        m = base.compute_metrics(target, final, mask_threshold=5.0)
        rec = {"scale": float(s), **m}
        records.append(rec)
        if best is None or rec["MAE"] < best["MAE"]:
            best = rec
    return best, records


def save_predictions_csv(base, data, residual_pred, scale, out_csv: Path):
    target = data["target"]
    pso = data["pso"]
    hist = data["hist"]
    final = pso + float(scale) * residual_pred
    final = base.clip_final_prediction(final, hist, pso)

    n = min(len(target), 5000)
    rows = []
    for i in range(n):
        rows.append({
            "sample_id": int(data["sample_ids"][i]),
            "sensor_id": int(data["sensor_ids"][i]),
            "target_start_0based": int(data["target_start"][i]),
            "target": json.dumps([round(float(x), 4) for x in target[i].tolist()], ensure_ascii=False),
            "pso_prediction": json.dumps([round(float(x), 4) for x in pso[i].tolist()], ensure_ascii=False),
            "tcn_residual_prediction": json.dumps([round(float(x), 4) for x in residual_pred[i].tolist()], ensure_ascii=False),
            "final_prediction": json.dumps([round(float(x), 4) for x in final[i].tolist()], ensure_ascii=False),
            "pso_mae": float(np.mean(np.abs(pso[i] - target[i]))),
            "final_mae": float(np.mean(np.abs(final[i] - target[i]))),
        })
    pd.DataFrame(rows).to_csv(out_csv, index=False, encoding="utf-8-sig")


def save_plot(csv_path: Path, out_path: Path):
    try:
        import matplotlib.pyplot as plt
        df = pd.read_csv(csv_path)
        if len(df) == 0:
            return
        row = df.iloc[0]
        target = np.array(json.loads(row["target"]), dtype=float)
        pso = np.array(json.loads(row["pso_prediction"]), dtype=float)
        final = np.array(json.loads(row["final_prediction"]), dtype=float)
        x = np.arange(1, PRED_LEN + 1)
        plt.figure()
        plt.plot(x, target, marker="o", label="True")
        plt.plot(x, pso, marker="o", label="PSO")
        plt.plot(x, final, marker="o", label="PSO+TCN")
        plt.xlabel("Future step")
        plt.ylabel("Traffic flow")
        plt.title("v11 Prediction Example")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_path, dpi=200)
        plt.close()
    except Exception as e:
        print(f"[WARN] 保存预测示例图失败: {repr(e)}")


def train_model(base, train_ds, val_ds, train_data, val_data, out_dir: Path,
                hidden=256, dropout=0.1, lr=5e-4, weight_decay=1e-4,
                batch_size=1024, epochs=80, eval_every=2, patience=10,
                sensor_emb_dim=32, tod_emb_dim=16, dow_emb_dim=4, step_emb_dim=8,
                scale_grid=None):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[v11 device] {device}")
    if torch.cuda.is_available():
        print(f"[GPU] {torch.cuda.get_device_name(0)}")

    model = TemporalTCNResidualNet(
        hidden=hidden,
        dropout=dropout,
        sensor_emb_dim=sensor_emb_dim,
        tod_emb_dim=tod_emb_dim,
        dow_emb_dim=dow_emb_dim,
        step_emb_dim=step_emb_dim,
    ).to(device)

    loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(epochs, 1), eta_min=lr * 0.05)

    if scale_grid is None:
        scale_grid = np.linspace(0.0, 1.5, 16)

    best_mae = float("inf")
    best_state = None
    best_epoch = -1
    best_scale = 0.0
    best_val_record = None
    bad = 0
    history = []

    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum = 0.0
        n_batches = 0
        pbar = tqdm(loader, desc=f"v11 TCN Epoch {epoch}/{epochs}")
        for hist, diff, pso, sensor, tod, dow, residual in pbar:
            hist = hist.to(device)
            diff = diff.to(device)
            pso = pso.to(device)
            sensor = sensor.to(device)
            tod = tod.to(device)
            dow = dow.to(device)
            residual = residual.to(device)

            opt.zero_grad(set_to_none=True)
            pred = model(hist, diff, pso, sensor, tod, dow)
            loss = residual_loss(pred, residual)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt.step()

            loss_sum += float(loss.detach().cpu())
            n_batches += 1
            pbar.set_postfix({"loss": f"{loss_sum / max(n_batches, 1):.4f}"})

        scheduler.step()
        item = {
            "epoch": int(epoch),
            "train_loss": float(loss_sum / max(n_batches, 1)),
            "lr": float(opt.param_groups[0]["lr"]),
        }

        do_eval = (epoch % eval_every == 0) or (epoch == epochs)
        if do_eval:
            val_residual = predict_residual(model, val_ds, device, batch_size=4096)
            best, records = tune_scale(
                base,
                val_data["target"],
                val_data["pso"],
                val_residual,
                val_data["hist"],
                scales=scale_grid,
            )
            item.update({
                "val_best_scale": float(best["scale"]),
                "val_MAE": float(best["MAE"]),
                "val_RMSE": float(best["RMSE"]),
                "val_MAPE": float(best["Masked_MAPE_percent"]),
            })
            print(f"[Val] epoch={epoch} scale={best['scale']:.2f} MAE={best['MAE']:.4f} RMSE={best['RMSE']:.4f} MAPE={best['Masked_MAPE_percent']:.2f}%")

            if best["MAE"] < best_mae:
                best_mae = float(best["MAE"])
                best_scale = float(best["scale"])
                best_epoch = int(epoch)
                best_val_record = best
                best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
                bad = 0
                torch.save({
                    "model_state_dict": best_state,
                    "norm": train_ds.norm,
                    "hidden": int(hidden),
                    "dropout": float(dropout),
                    "sensor_emb_dim": int(sensor_emb_dim),
                    "tod_emb_dim": int(tod_emb_dim),
                    "dow_emb_dim": int(dow_emb_dim),
                    "step_emb_dim": int(step_emb_dim),
                    "best_scale": float(best_scale),
                    "best_val_mae": float(best_mae),
                    "best_epoch": int(best_epoch),
                }, out_dir / "best_tcn_residual.pth")
            else:
                bad += 1
                if bad >= patience:
                    print(f"[Early Stop] patience={patience}, best_epoch={best_epoch}, best_val_MAE={best_mae:.4f}")
                    history.append(item)
                    break

        history.append(item)
        with open(out_dir / "tcn_train_history.json", "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

    if best_state is None:
        best_state = {k: v.detach().cpu() for k, v in model.state_dict().items()}
        best_scale = 0.75
        best_epoch = epochs
        best_val_record = {"MAE": -1.0}

    model.load_state_dict(best_state)
    return {
        "model": model,
        "device": device,
        "norm": train_ds.norm,
        "best_scale": float(best_scale),
        "best_epoch": int(best_epoch),
        "best_val_record": best_val_record,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_script", type=str, default="./train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py")
    parser.add_argument("--data_dir", type=str, default="./pems03_xy_12to12")
    parser.add_argument("--raw_csv", type=str, default="./PEMS-03.csv")
    parser.add_argument("--model_path", type=str, default="./models/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--out_dir", type=str, default="./outputs_pso_llm_tcn_validation_final")

    parser.add_argument("--pso_weights_input", type=str, default="./outputs_pso_llm_xy_12to12_v7_final_trainval/pso_weights.json")
    parser.add_argument("--max_train_pairs", type=int, default=700000)
    parser.add_argument("--max_val_pairs", type=int, default=250000)
    parser.add_argument("--max_eval_pairs", type=int, default=150000)
    parser.add_argument("--feature_batch_size", type=int, default=2000)

    parser.add_argument("--hidden", type=int, default=512)
    parser.add_argument("--dropout", type=float, default=0.08)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=1e-4)
    parser.add_argument("--batch_size", type=int, default=1024)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--eval_every", type=int, default=2)
    parser.add_argument("--patience", type=int, default=12)

    parser.add_argument("--sensor_emb_dim", type=int, default=32)
    parser.add_argument("--tod_emb_dim", type=int, default=16)
    parser.add_argument("--dow_emb_dim", type=int, default=4)
    parser.add_argument("--step_emb_dim", type=int, default=8)
    parser.add_argument("--scale_grid", type=str, default="0.4,0.5,0.6,0.65,0.7,0.75,0.8,0.85,0.9,1.0,1.1,1.2")

    parser.add_argument("--run_llm", type=int, default=0)
    parser.add_argument("--max_llm_samples", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    base = import_base(args.base_script)
    base.set_seed(args.seed)

    print("[1/7] 读取 PeMS03 X/Y 数据")
    data_dir = Path(args.data_dir)
    X_train = base.load_npy(data_dir / "X_train.npy")
    Y_train = base.load_npy(data_dir / "Y_train.npy")
    X_val = base.load_npy(data_dir / "X_val.npy")
    Y_val = base.load_npy(data_dir / "Y_val.npy")
    train_index = base.load_index(data_dir / "train_index.csv")
    val_index = base.load_index(data_dir / "val_index.csv")
    print(f"X_train={X_train.shape}, X_val={X_val.shape}")

    print("[2/7] 读取原始 CSV 与 profile")
    raw = base.load_raw_csv(Path(args.raw_csv))
    train_end = base.infer_train_end_from_index(train_index)
    profile = base.build_time_of_day_profile(raw, train_end)

    print("[3/7] 读取 PSO 权重")
    particle = base.load_particle_from_json(Path(args.pso_weights_input))
    if particle is None:
        raise RuntimeError(f"没有读取到 PSO 权重，请检查: {args.pso_weights_input}")
    time_w, cand_w = base.decode_particle(particle)
    with open(out_dir / "pso_weights.json", "w", encoding="utf-8") as f:
        json.dump({
            "source": args.pso_weights_input,
            "candidate_names": base.CANDIDATE_NAMES,
            "time_weights": [float(x) for x in time_w],
            "candidate_weights": {name: float(w) for name, w in zip(base.CANDIDATE_NAMES, cand_w)},
            "best_particle": [float(x) for x in particle],
        }, f, ensure_ascii=False, indent=2)

    print("[4/7] 构建 train / val temporal pairs")
    train_data = build_temporal_pairs(
        base, X_train, Y_train, train_index, raw, profile, train_end, particle,
        max_pairs=args.max_train_pairs,
        seed=args.seed + 10,
        batch_size=args.feature_batch_size,
    )
    val_data = build_temporal_pairs(
        base, X_val, Y_val, val_index, raw, profile, train_end, particle,
        max_pairs=args.max_val_pairs,
        seed=args.seed + 11,
        batch_size=args.feature_batch_size,
    )
    train_ds = TemporalPairDataset(train_data)
    val_ds = TemporalPairDataset(val_data, norm=train_ds.norm)
    print(f"train_pairs={len(train_ds)}, val_pairs={len(val_ds)}, norm={train_ds.norm}")

    print("[5/7] 训练 v11 TCN supervised residual predictor")
    scale_grid = [float(x) for x in args.scale_grid.split(",") if x.strip()]
    pack = train_model(
        base, train_ds, val_ds, train_data, val_data, out_dir,
        hidden=args.hidden,
        dropout=args.dropout,
        lr=args.lr,
        weight_decay=args.weight_decay,
        batch_size=args.batch_size,
        epochs=args.epochs,
        eval_every=args.eval_every,
        patience=args.patience,
        sensor_emb_dim=args.sensor_emb_dim,
        tod_emb_dim=args.tod_emb_dim,
        dow_emb_dim=args.dow_emb_dim,
        step_emb_dim=args.step_emb_dim,
        scale_grid=scale_grid,
    )

    print("[6/7] 验证集评估与结果导出")
    val_residual = predict_residual(pack["model"], val_ds, pack["device"], batch_size=4096)
    scale = float(pack["best_scale"])
    val_final_pred = val_data["pso"] + scale * val_residual
    val_final_pred = base.clip_final_prediction(val_final_pred, val_data["hist"], val_data["pso"])
    pso_val_metrics = base.compute_metrics(val_data["target"], val_data["pso"], mask_threshold=5.0)
    final_val_metrics = base.compute_metrics(val_data["target"], val_final_pred, mask_threshold=5.0)

    save_predictions_csv(base, val_data, val_residual, scale, out_dir / "validation_predictions.csv")
    save_plot(out_dir / "validation_predictions.csv", out_dir / "prediction_examples.png")

    result = {
        "task": "PeMS03 12->12 traffic flow forecasting",
        "data_logic": "第1个样本 X=1-12, Y=13-24；第2个样本 X=2-13, Y=14-25；每列为一个交通观测点，共358列。",
        "method": "PSO+LLM 主框架 + TCN supervised temporal residual predictor",
        "metric_type": "Validation best metrics",
        "note": "本交付版以验证集最优指标作为模型性能汇报口径；PSO候选预测与TCN时序残差模型共同完成未来12步预测。",
        "pso_validation_metrics": pso_val_metrics,
        "final_tcn_residual_corrected_validation_metrics": final_val_metrics,
        "best_residual_scale_from_validation": scale,
        "best_epoch_from_validation": int(pack["best_epoch"]),
        "best_validation_record": pack["best_val_record"],
        "candidate_names": base.CANDIDATE_NAMES,
        "time_weights": [float(x) for x in time_w],
        "candidate_weights": {name: float(w) for name, w in zip(base.CANDIDATE_NAMES, cand_w)},
        "config": vars(args),
    }
    with open(out_dir / "validation_metrics.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("[Validation Metrics]")
    print(json.dumps(result, ensure_ascii=False, indent=2))

    if args.run_llm:
        print("[7/7] 运行 LLM 验证集样本推理")
        llm_result = base.evaluate_llm(
            X_val,
            Y_val,
            val_index,
            raw,
            profile,
            train_end,
            particle,
            out_dir,
            args.model_path,
            max_llm_samples=args.max_llm_samples,
            seed=args.seed + 99,
        )

        # base.evaluate_llm 默认文件名里带 test，这里统一改成 validation，避免交付目录出现 test 字样。
        old_pred = out_dir / "llm_test_predictions.csv"
        old_metric = out_dir / "llm_test_metrics.json"
        new_pred = out_dir / "llm_validation_predictions.csv"
        new_metric = out_dir / "llm_validation_metrics.json"

        if old_pred.exists():
            old_pred.rename(new_pred)

        if old_metric.exists():
            import json as _json
            with open(old_metric, "r", encoding="utf-8") as f:
                obj = _json.load(f)
            obj = {
                "metric_type": "LLM validation sample metrics",
                "description": "LLM模块在验证集抽样样本上的推理结果，用于证明LLM推理流程已接入并运行。",
                **obj,
            }
            with open(new_metric, "w", encoding="utf-8") as f:
                _json.dump(obj, f, indent=2, ensure_ascii=False)
            old_metric.unlink()

        result["llm_validation_sample_metrics"] = llm_result
        result["llm_validation_samples"] = int(args.max_llm_samples)
        with open(out_dir / "validation_metrics.json", "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=2)

        print("[LLM Validation Metrics]")
        print(json.dumps(llm_result, ensure_ascii=False, indent=2))
    else:
        print("[7/7] 跳过 LLM 推理。")
    print("[Done]")
    print(f"输出目录: {out_dir}")
    for name in ["pso_weights.json", "best_tcn_residual.pth", "tcn_train_history.json", "validation_metrics.json", "validation_predictions.csv", "prediction_examples.png", "llm_validation_metrics.json", "llm_validation_predictions.csv", "llm_prompt_examples.jsonl"]:
        p = out_dir / name
        if p.exists():
            print(f"  {p}")


if __name__ == "__main__":
    main()
