#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_llm_finetune_data_pems03.py

作用：
  将 PeMS03 12->12 交通流量预测数据转换成大模型指令微调数据。
  每条样本对应：一个时间窗口 + 一个传感器节点。

输出：
  1) Alpaca 格式：
      train_alpaca.jsonl
      val_alpaca.jsonl

  2) Chat messages 格式：
      train_messages.jsonl
      val_messages.jsonl

  3) 辅助文件：
      prompt_preview.jsonl
      train_sample_index.csv
      val_sample_index.csv
      data_stats.json

说明：
  - input/prompt 使用历史12步流量、PSO权重、候选预测结果、PSO融合预测、峰值和趋势信息。
  - output 使用真实未来12步流量，格式严格为 JSON：
      {"sensor_id":"sensor_x","predicted_flow":[...12个数...]}
  - 生成的是 LLM/LoRA 微调训练数据，不会训练模型。
"""

import argparse
import importlib.util
import json
import random
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


SEQ_LEN = 12
PRED_LEN = 12


def import_base(path: str):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"找不到 base 脚本: {path}")
    spec = importlib.util.spec_from_file_location("pso_llm_base", str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def round_list(arr, ndigits=3):
    return [round(float(x), ndigits) for x in np.asarray(arr).reshape(-1).tolist()]


def make_target_json(sensor_id, target, ndigits=3):
    obj = {
        "sensor_id": f"sensor_{int(sensor_id)}",
        "predicted_flow": round_list(target, ndigits),
    }
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def make_alpaca_record(prompt, answer):
    return {
        "instruction": "请根据历史交通流量、PSO权重、候选预测结果、PSO融合预测、峰值时刻和趋势描述，预测未来12个时间步交通流量。只输出JSON。",
        "input": prompt,
        "output": answer,
    }


def make_messages_record(prompt, answer):
    return {
        "messages": [
            {
                "role": "system",
                "content": "你是严谨的交通流量预测助手。你必须只输出JSON，不要解释。predicted_flow必须是长度为12的数字数组。",
            },
            {
                "role": "user",
                "content": prompt,
            },
            {
                "role": "assistant",
                "content": answer,
            },
        ]
    }


def write_jsonl_line(fp, obj):
    fp.write(json.dumps(obj, ensure_ascii=False) + "\n")


def process_split(
    *,
    base,
    split_name: str,
    X,
    Y,
    index_df,
    raw,
    profile,
    train_end,
    particle,
    out_dir: Path,
    max_samples: int,
    seed: int,
    batch_size: int,
    output_format: str,
    round_ndigits: int,
    preview_fp,
):
    print(f"\n[Generate {split_name}] max_samples={max_samples}")

    sample_ids, sensor_ids, target_start = base.sample_pairs(
        X, Y, index_df, max_pairs=max_samples, seed=seed
    )

    total = len(sample_ids)
    print(f"[{split_name}] selected node-window samples: {total}")

    time_w, cand_w = base.decode_particle(particle)

    alpaca_fp = None
    messages_fp = None
    if output_format in ("alpaca", "both"):
        alpaca_fp = open(out_dir / f"{split_name}_alpaca.jsonl", "w", encoding="utf-8")
    if output_format in ("messages", "both"):
        messages_fp = open(out_dir / f"{split_name}_messages.jsonl", "w", encoding="utf-8")

    index_rows = []
    written = 0

    for st in tqdm(range(0, total, batch_size), desc=f"{split_name} batches"):
        ed = min(st + batch_size, total)
        sid = sample_ids[st:ed]
        sen = sensor_ids[st:ed]
        ts = target_start[st:ed]

        hist, target = base.gather_xy(X, Y, sid, sen)

        # 每个batch一次性构造候选预测，速度比逐条构造快。
        candidates_all = base.build_candidates(
            hist,
            time_w,
            raw,
            ts,
            sen,
            profile=profile,
            train_end=train_end,
        )
        pso_pred_all = base.fuse_candidates(candidates_all, cand_w)

        for j in range(ed - st):
            i = st + j
            prompt = base.build_llm_prompt(
                int(sen[j]),
                hist[j],
                pso_pred_all[j],
                candidates_all[j],
                time_w,
                cand_w,
            )
            answer = make_target_json(int(sen[j]), target[j], ndigits=round_ndigits)

            if alpaca_fp is not None:
                write_jsonl_line(alpaca_fp, make_alpaca_record(prompt, answer))
            if messages_fp is not None:
                write_jsonl_line(messages_fp, make_messages_record(prompt, answer))

            if preview_fp is not None and written < 20:
                write_jsonl_line(preview_fp, {
                    "split": split_name,
                    "sample_id": int(sid[j]),
                    "sensor_id": int(sen[j]),
                    "target_start_0based": int(ts[j]),
                    "prompt": prompt,
                    "answer": answer,
                })

            index_rows.append({
                "split": split_name,
                "row_id": int(i),
                "sample_id": int(sid[j]),
                "sensor_id": int(sen[j]),
                "target_start_0based": int(ts[j]),
            })
            written += 1

    if alpaca_fp is not None:
        alpaca_fp.close()
    if messages_fp is not None:
        messages_fp.close()

    index_path = out_dir / f"{split_name}_sample_index.csv"
    pd.DataFrame(index_rows).to_csv(index_path, index=False, encoding="utf-8-sig")

    return {
        "split": split_name,
        "num_samples": int(written),
        "alpaca_file": str(out_dir / f"{split_name}_alpaca.jsonl") if output_format in ("alpaca", "both") else None,
        "messages_file": str(out_dir / f"{split_name}_messages.jsonl") if output_format in ("messages", "both") else None,
        "index_file": str(index_path),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base_script", type=str, default="./train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py")
    parser.add_argument("--data_dir", type=str, default="./pems03_xy_12to12")
    parser.add_argument("--raw_csv", type=str, default="./PEMS-03.csv")
    parser.add_argument("--pso_weights", type=str, default="./outputs_pso_llm_xy_12to12_v11_tcn_full/pso_weights.json")
    parser.add_argument("--out_dir", type=str, default="./llm_finetune_data_pems03")

    parser.add_argument("--max_train_samples", type=int, default=100000)
    parser.add_argument("--max_val_samples", type=int, default=20000)
    parser.add_argument("--batch_size", type=int, default=1000)
    parser.add_argument("--format", type=str, default="both", choices=["alpaca", "messages", "both"])
    parser.add_argument("--round_ndigits", type=int, default=3)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)
    np.random.seed(args.seed)

    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    print("[1/6] 导入基础 PSO/Prompt 工具脚本")
    base = import_base(args.base_script)

    print("[2/6] 读取 X/Y 数据")
    data_dir = Path(args.data_dir)
    X_train = base.load_npy(data_dir / "X_train.npy")
    Y_train = base.load_npy(data_dir / "Y_train.npy")
    X_val = base.load_npy(data_dir / "X_val.npy")
    Y_val = base.load_npy(data_dir / "Y_val.npy")
    train_index = base.load_index(data_dir / "train_index.csv")
    val_index = base.load_index(data_dir / "val_index.csv")

    print(f"X_train={X_train.shape}, Y_train={Y_train.shape}")
    print(f"X_val={X_val.shape}, Y_val={Y_val.shape}")

    print("[3/6] 读取原始 CSV 与训练集 profile")
    raw = base.load_raw_csv(Path(args.raw_csv))
    train_end = base.infer_train_end_from_index(train_index)
    profile = base.build_time_of_day_profile(raw, train_end)

    print("[4/6] 读取 PSO 权重")
    particle = base.load_particle_from_json(Path(args.pso_weights))
    if particle is None:
        raise RuntimeError(f"没有读取到 PSO 权重，请检查: {args.pso_weights}")

    time_w, cand_w = base.decode_particle(particle)
    with open(out_dir / "pso_weights_used.json", "w", encoding="utf-8") as f:
        json.dump({
            "source": args.pso_weights,
            "candidate_names": base.CANDIDATE_NAMES,
            "time_weights": [float(x) for x in time_w],
            "candidate_weights": {name: float(w) for name, w in zip(base.CANDIDATE_NAMES, cand_w)},
        }, f, indent=2, ensure_ascii=False)

    print("[5/6] 生成 LLM 微调数据")
    preview_fp = open(out_dir / "prompt_preview.jsonl", "w", encoding="utf-8")

    train_info = process_split(
        base=base,
        split_name="train",
        X=X_train,
        Y=Y_train,
        index_df=train_index,
        raw=raw,
        profile=profile,
        train_end=train_end,
        particle=particle,
        out_dir=out_dir,
        max_samples=args.max_train_samples,
        seed=args.seed,
        batch_size=args.batch_size,
        output_format=args.format,
        round_ndigits=args.round_ndigits,
        preview_fp=preview_fp,
    )

    val_info = process_split(
        base=base,
        split_name="val",
        X=X_val,
        Y=Y_val,
        index_df=val_index,
        raw=raw,
        profile=profile,
        train_end=train_end,
        particle=particle,
        out_dir=out_dir,
        max_samples=args.max_val_samples,
        seed=args.seed + 100,
        batch_size=args.batch_size,
        output_format=args.format,
        round_ndigits=args.round_ndigits,
        preview_fp=preview_fp,
    )

    preview_fp.close()

    print("[6/6] 保存统计信息")
    stats = {
        "task": "PeMS03 12->12 LLM instruction finetuning data",
        "description": "每条样本对应一个交通节点在一个时间窗口上的未来12步预测任务。",
        "data_logic": "input为历史12步流量、PSO权重、候选预测、PSO融合预测、峰值和趋势信息；output为真实未来12步流量JSON。",
        "seq_len": SEQ_LEN,
        "pred_len": PRED_LEN,
        "num_sensors": int(X_train.shape[2]),
        "train_window_samples": int(X_train.shape[0]),
        "val_window_samples": int(X_val.shape[0]),
        "theoretical_train_node_window_samples": int(X_train.shape[0] * X_train.shape[2]),
        "theoretical_val_node_window_samples": int(X_val.shape[0] * X_val.shape[2]),
        "selected_train_samples": int(train_info["num_samples"]),
        "selected_val_samples": int(val_info["num_samples"]),
        "format": args.format,
        "round_ndigits": args.round_ndigits,
        "files": {
            "train": train_info,
            "val": val_info,
            "prompt_preview": str(out_dir / "prompt_preview.jsonl"),
            "pso_weights_used": str(out_dir / "pso_weights_used.json"),
        },
    }
    with open(out_dir / "data_stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2, ensure_ascii=False)

    print("\n[Done] LLM 微调数据已生成：")
    print(json.dumps(stats, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
