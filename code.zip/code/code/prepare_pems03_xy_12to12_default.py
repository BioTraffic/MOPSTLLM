#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
prepare_pems03_xy_12to12_default.py

按客户要求重新构造 PeMS03 的 12->12 滑动窗口数据集。

客户要求的样本逻辑：
  第1个样本：输入 1-12 个时间步，标签 13-24 个时间步
  第2个样本：输入 2-13 个时间步，标签 14-25 个时间步
  第3个样本：输入 3-14 个时间步，标签 15-26 个时间步
  ...

PeMS03 数据结构：
  每一行 = 一个时间步，约 5 分钟采样一次
  每一列 = 一个观测点/传感器，共 358 列

默认路径：
  输入：/root/autodl-tmp/PEMS-03.csv
  输出：/root/autodl-tmp/pems03_xy_12to12

默认输出：
  X_train.npy, Y_train.npy
  X_val.npy,   Y_val.npy
  X_test.npy,  Y_test.npy

数组形状：
  X_*.npy: [样本数, 12, 358]
  Y_*.npy: [样本数, 12, 358]

划分方式：
  先按时间顺序切分原始序列 train/val/test，再在每个片段内部按 12->12 构造滑动窗口。
  这样既满足客户的滑动窗口逻辑，也避免训练样本的标签跨入验证集/测试集。
"""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm


SEQ_LEN = 12
PRED_LEN = 12


def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def read_pems_csv(path: Path) -> np.ndarray:
    if not path.exists():
        raise FileNotFoundError(f"找不到输入文件: {path}")
    print(f"[Load] {path}")
    arr = pd.read_csv(path, header=None).values.astype(np.float32)
    if arr.ndim != 2:
        raise ValueError(f"数据维度错误，应为二维矩阵，当前: {arr.shape}")
    print(f"[Shape] {arr.shape} = 时间步数 × 观测点数")
    return arr


def build_xy_memmap(segment: np.ndarray, global_offset: int, out_dir: Path, split_name: str):
    """
    segment: 当前 split 的原始时间序列片段 [T_split, N_sensor]
    global_offset: 当前 split 在原始全局序列中的起始下标，0-based
    """
    t_len, n_sensor = segment.shape
    n_samples = t_len - SEQ_LEN - PRED_LEN + 1
    if n_samples <= 0:
        raise ValueError(f"{split_name} 片段太短，无法构造 12->12 样本: len={t_len}")

    x_path = out_dir / f"X_{split_name}.npy"
    y_path = out_dir / f"Y_{split_name}.npy"
    idx_path = out_dir / f"{split_name}_index.csv"

    print(f"[Build {split_name}] segment_len={t_len}, samples={n_samples}, sensors={n_sensor}")
    print(f"  X: {x_path}")
    print(f"  Y: {y_path}")

    # 使用 open_memmap，避免一次性占用过多内存
    X = np.lib.format.open_memmap(
        x_path, mode="w+", dtype=np.float32, shape=(n_samples, SEQ_LEN, n_sensor)
    )
    Y = np.lib.format.open_memmap(
        y_path, mode="w+", dtype=np.float32, shape=(n_samples, PRED_LEN, n_sensor)
    )

    rows = []
    for i in tqdm(range(n_samples), desc=f"{split_name} windows"):
        X[i] = segment[i:i + SEQ_LEN, :]
        Y[i] = segment[i + SEQ_LEN:i + SEQ_LEN + PRED_LEN, :]

        # 保存1-based全局行号，方便和客户说明对应关系
        rows.append({
            "sample_id": i,
            "input_start_row_1based": global_offset + i + 1,
            "input_end_row_1based": global_offset + i + SEQ_LEN,
            "target_start_row_1based": global_offset + i + SEQ_LEN + 1,
            "target_end_row_1based": global_offset + i + SEQ_LEN + PRED_LEN,
            "input_logic": f"{global_offset + i + 1}-{global_offset + i + SEQ_LEN}",
            "target_logic": f"{global_offset + i + SEQ_LEN + 1}-{global_offset + i + SEQ_LEN + PRED_LEN}",
        })

    # 显式flush
    del X
    del Y

    pd.DataFrame(rows).to_csv(idx_path, index=False, encoding="utf-8-sig")

    return {
        "split": split_name,
        "segment_len": int(t_len),
        "num_samples": int(n_samples),
        "num_sensors": int(n_sensor),
        "X_path": str(x_path),
        "Y_path": str(y_path),
        "index_path": str(idx_path),
        "first_sample": rows[0],
        "second_sample": rows[1] if len(rows) > 1 else None,
        "last_sample": rows[-1],
    }


def save_preview(arr: np.ndarray, out_dir: Path):
    """
    保存前几个窗口的文字预览，只显示行号逻辑，不展开358列数值。
    """
    total_t = arr.shape[0]
    rows = []
    max_preview = min(10, total_t - SEQ_LEN - PRED_LEN + 1)
    for i in range(max_preview):
        rows.append({
            "sample_id": i,
            "input": f"{i + 1}-{i + SEQ_LEN}",
            "target": f"{i + SEQ_LEN + 1}-{i + SEQ_LEN + PRED_LEN}",
            "说明": f"输入第{i + 1}到第{i + SEQ_LEN}个时间步，预测第{i + SEQ_LEN + 1}到第{i + SEQ_LEN + PRED_LEN}个时间步"
        })
    pd.DataFrame(rows).to_csv(out_dir / "window_logic_preview.csv", index=False, encoding="utf-8-sig")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=str, default="/root/autodl-tmp/PEMS-03.csv")
    parser.add_argument("--out_dir", type=str, default="/root/autodl-tmp/pems03_xy_12to12")
    parser.add_argument("--train_ratio", type=float, default=0.6)
    parser.add_argument("--val_ratio", type=float, default=0.2)
    args = parser.parse_args()

    input_path = Path(args.input)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    arr = read_pems_csv(input_path)
    total_t, n_sensor = arr.shape

    train_end = int(total_t * args.train_ratio)
    val_end = int(total_t * (args.train_ratio + args.val_ratio))

    train_seg = arr[:train_end, :]
    val_seg = arr[train_end:val_end, :]
    test_seg = arr[val_end:, :]

    print("\n[Split raw time series]")
    print(f"  train rows: 1-{train_end}, shape={train_seg.shape}")
    print(f"  val rows:   {train_end + 1}-{val_end}, shape={val_seg.shape}")
    print(f"  test rows:  {val_end + 1}-{total_t}, shape={test_seg.shape}")

    split_results = []
    split_results.append(build_xy_memmap(train_seg, 0, out_dir, "train"))
    split_results.append(build_xy_memmap(val_seg, train_end, out_dir, "val"))
    split_results.append(build_xy_memmap(test_seg, val_end, out_dir, "test"))

    save_preview(arr, out_dir)

    info = {
        "input_file": str(input_path),
        "output_dir": str(out_dir),
        "original_shape": {
            "time_steps": int(total_t),
            "sensors": int(n_sensor)
        },
        "sampling_interval_minutes": 5,
        "seq_len": SEQ_LEN,
        "pred_len": PRED_LEN,
        "task": "12->12，即过去12个时间步预测未来12个时间步",
        "time_meaning": "过去60分钟预测未来60分钟",
        "customer_required_logic": [
            "第1个样本：输入1-12个时间步，标签13-24个时间步",
            "第2个样本：输入2-13个时间步，标签14-25个时间步",
            "第3个样本：输入3-14个时间步，标签15-26个时间步"
        ],
        "split_strategy": "先按时间顺序划分原始序列，再在各自片段内部构造12->12滑动窗口，避免标签跨越数据集边界。",
        "splits": split_results,
        "array_shape_description": {
            "X": "[样本数, 12, 358]",
            "Y": "[样本数, 12, 358]"
        }
    }

    with open(out_dir / "dataset_info.json", "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)

    print("\n[Done]")
    print(f"输出目录: {out_dir}")
    print("主要文件：")
    for name in [
        "X_train.npy", "Y_train.npy", "train_index.csv",
        "X_val.npy", "Y_val.npy", "val_index.csv",
        "X_test.npy", "Y_test.npy", "test_index.csv",
        "window_logic_preview.csv", "dataset_info.json"
    ]:
        print(f"  {out_dir / name}")

    print("\n[客户口径说明]")
    print("已按 12->12 滑动窗口构造：")
    print("  第1个样本：X=1-12，Y=13-24")
    print("  第2个样本：X=2-13，Y=14-25")
    print("  每一列是一个观测点，共358列。")


if __name__ == "__main__":
    main()
