#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_llm_lora_pems03_safe.py

作用：
  在当前 PeMS03 PSO+TCN 主预测结果基础上，增加 Llama/Qwen 等大模型 LoRA 微调训练。
  该脚本不会覆盖原来的 PSO+TCN 主结果，而是单独训练 LLM LoRA，并在验证集样本上评估。

核心原则：
  1. 先保留当前 PSO+TCN 验证集 MAE=13.5772 作为安全基线；
  2. LLM LoRA 训练完成后，只作为增强模块；
  3. 如果 LLM LoRA 验证结果没有优于当前基线，最终交付仍保留 PSO+TCN 主结果；
  4. 因此最终主指标不会比当前结果差。

输入：
  - generate_llm_finetune_data_pems03.py 生成的 train_messages.jsonl / val_messages.jsonl
  - 本地大模型目录，例如 ./models/Meta-Llama-3-8B-Instruct
  - 当前 PSO+TCN 的 validation_metrics.json

输出：
  - lora_adapter/                       LoRA 权重
  - lora_validation_metrics.json         LLM LoRA 验证集抽样指标
  - lora_validation_predictions.csv      LLM LoRA 验证集抽样预测结果
  - final_safe_decision.json             是否采用 LLM 结果的安全决策
"""

import argparse
import json
import math
import os
import re
import time
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm

from transformers import AutoTokenizer, AutoModelForCausalLM

try:
    from transformers import BitsAndBytesConfig
except Exception:
    BitsAndBytesConfig = None

try:
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel
except Exception as e:
    raise RuntimeError(
        "缺少 peft。请先安装：pip install peft accelerate transformers bitsandbytes"
    ) from e


def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def read_jsonl(path: Path, limit: int = 0):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            rows.append(json.loads(line))
            if limit and len(rows) >= limit:
                break
    return rows


def extract_answer_from_record(obj):
    if "messages" in obj:
        for m in reversed(obj["messages"]):
            if m.get("role") == "assistant":
                return m.get("content", "")
    if "output" in obj:
        return obj["output"]
    return ""


def extract_prompt_messages(obj):
    """
    返回 messages 格式，最后不包含 assistant answer，用于生成。
    """
    if "messages" in obj:
        return [m for m in obj["messages"] if m.get("role") != "assistant"]

    instruction = obj.get("instruction", "")
    inp = obj.get("input", "")
    return [
        {
            "role": "system",
            "content": "你是严谨的交通流量预测助手。你必须只输出JSON，不要解释。predicted_flow必须是长度为12的数字数组。",
        },
        {
            "role": "user",
            "content": instruction + "\n\n" + inp,
        },
    ]


def build_prompt_text(tokenizer, obj):
    messages = extract_prompt_messages(obj)
    try:
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )
    except Exception:
        # tokenizer 没有 chat_template 时的兜底格式
        parts = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content", "")
            parts.append(f"<{role}>\n{content}\n</{role}>")
        parts.append("<assistant>\n")
        return "\n".join(parts)


def build_train_texts(tokenizer, obj):
    prompt = build_prompt_text(tokenizer, obj)
    answer = extract_answer_from_record(obj).strip()
    if tokenizer.eos_token:
        answer = answer + tokenizer.eos_token
    return prompt, answer


def parse_predicted_flow(text, pred_len=12):
    """
    从模型输出中解析 predicted_flow。
    优先解析 JSON，其次正则提取数字。
    """
    if not text:
        return None

    cleaned = text.strip()

    # 尝试提取 {...}
    json_match = re.search(r"\{.*\}", cleaned, flags=re.S)
    if json_match:
        candidate = json_match.group(0)
        try:
            obj = json.loads(candidate)
            arr = obj.get("predicted_flow", None)
            if isinstance(arr, list) and len(arr) == pred_len:
                return [max(0.0, float(x)) for x in arr]
        except Exception:
            pass

    # 尝试提取 predicted_flow 后面的数组
    arr_match = re.search(r"predicted_flow[^\[]*\[([^\]]+)\]", cleaned, flags=re.S)
    if arr_match:
        nums = re.findall(r"-?\d+(?:\.\d+)?", arr_match.group(1))
        if len(nums) >= pred_len:
            return [max(0.0, float(x)) for x in nums[:pred_len]]

    # 兜底：直接取全文前12个数字
    nums = re.findall(r"-?\d+(?:\.\d+)?", cleaned)
    if len(nums) >= pred_len:
        return [max(0.0, float(x)) for x in nums[:pred_len]]

    return None


def parse_target_flow(answer, pred_len=12):
    try:
        obj = json.loads(answer)
        arr = obj.get("predicted_flow", None)
        if isinstance(arr, list) and len(arr) == pred_len:
            return [float(x) for x in arr]
    except Exception:
        pass
    nums = re.findall(r"-?\d+(?:\.\d+)?", answer)
    if len(nums) >= pred_len:
        # 如果包含 sensor_id 中的数字，优先取最后12个数作为 target
        return [float(x) for x in nums[-pred_len:]]
    return None


def compute_metrics(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    err = y_pred - y_true
    abs_err = np.abs(err)

    mae = float(abs_err.mean())
    rmse = float(np.sqrt(np.mean(err ** 2)))

    mask = np.abs(y_true) > 5.0
    if mask.sum() > 0:
        masked_mae = float(abs_err[mask].mean())
        masked_rmse = float(np.sqrt(np.mean((err[mask]) ** 2)))
        masked_mape = float((abs_err[mask] / np.maximum(np.abs(y_true[mask]), 1e-6)).mean() * 100.0)
    else:
        masked_mae = mae
        masked_rmse = rmse
        masked_mape = float("nan")

    peak_true = y_true.max(axis=1)
    peak_pred = y_pred.max(axis=1)
    peak_mae = float(np.abs(peak_pred - peak_true).mean())

    return {
        "MAE": mae,
        "RMSE": rmse,
        "Masked_MAE": masked_mae,
        "Masked_RMSE": masked_rmse,
        "Masked_MAPE_percent": masked_mape,
        "Peak_MAE": peak_mae,
    }


def find_baseline_metrics(path: Path):
    """
    尽量兼容当前 validation_metrics.json 格式。
    """
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)

    candidates = [
        obj.get("final_tcn_residual_corrected_validation_metrics"),
        obj.get("validation_metrics"),
        obj.get("best_validation_record"),
        obj.get("best_val_record"),
    ]
    for c in candidates:
        if isinstance(c, dict) and "MAE" in c:
            return c

    # 递归兜底搜索第一个包含 MAE/RMSE 的 dict
    def walk(x):
        if isinstance(x, dict):
            if "MAE" in x and "RMSE" in x:
                return x
            for v in x.values():
                r = walk(v)
                if r is not None:
                    return r
        elif isinstance(x, list):
            for v in x:
                r = walk(v)
                if r is not None:
                    return r
        return None

    return walk(obj)


class SFTDataset(Dataset):
    def __init__(self, rows, tokenizer, max_len=2048):
        self.rows = rows
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        obj = self.rows[idx]
        prompt, answer = build_train_texts(self.tokenizer, obj)

        prompt_ids = self.tokenizer(prompt, add_special_tokens=False).input_ids
        answer_ids = self.tokenizer(answer, add_special_tokens=False).input_ids

        # 保留 answer，必要时截断 prompt
        if len(prompt_ids) + len(answer_ids) > self.max_len:
            keep_prompt = max(1, self.max_len - len(answer_ids))
            prompt_ids = prompt_ids[-keep_prompt:]

        input_ids = prompt_ids + answer_ids
        labels = [-100] * len(prompt_ids) + answer_ids

        if len(input_ids) > self.max_len:
            input_ids = input_ids[:self.max_len]
            labels = labels[:self.max_len]

        attention_mask = [1] * len(input_ids)

        return {
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "attention_mask": torch.tensor(attention_mask, dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


def collate_fn(features, pad_id):
    max_len = max(len(x["input_ids"]) for x in features)
    input_ids, attention_mask, labels = [], [], []
    for x in features:
        n = len(x["input_ids"])
        pad_n = max_len - n
        input_ids.append(torch.cat([x["input_ids"], torch.full((pad_n,), pad_id, dtype=torch.long)]))
        attention_mask.append(torch.cat([x["attention_mask"], torch.zeros(pad_n, dtype=torch.long)]))
        labels.append(torch.cat([x["labels"], torch.full((pad_n,), -100, dtype=torch.long)]))
    return {
        "input_ids": torch.stack(input_ids),
        "attention_mask": torch.stack(attention_mask),
        "labels": torch.stack(labels),
    }


def load_model_and_tokenizer(args):
    print(f"[Load tokenizer] {args.model_path}")
    tokenizer = AutoTokenizer.from_pretrained(args.model_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "right"

    print(f"[Load model] {args.model_path}")

    quant_config = None
    if args.load_in_4bit:
        if BitsAndBytesConfig is None:
            print("[WARN] transformers BitsAndBytesConfig 不可用，自动改为非4bit加载。")
        else:
            quant_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16 if args.bf16 else torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4",
            )

    model_kwargs = {
        "trust_remote_code": True,
        "device_map": "auto",
    }
    if quant_config is not None:
        model_kwargs["quantization_config"] = quant_config
    else:
        model_kwargs["torch_dtype"] = torch.bfloat16 if args.bf16 else torch.float16

    model = AutoModelForCausalLM.from_pretrained(args.model_path, **model_kwargs)

    if args.gradient_checkpointing:
        model.gradient_checkpointing_enable()
        try:
            model.config.use_cache = False
        except Exception:
            pass

    if quant_config is not None:
        model = prepare_model_for_kbit_training(model)

    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        target_modules=[x.strip() for x in args.target_modules.split(",") if x.strip()],
        lora_dropout=args.lora_dropout,
        bias="none",
        task_type="CAUSAL_LM",
    )

    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()
    return model, tokenizer


@torch.no_grad()
def eval_loss(model, loader, device, bf16=True, max_batches=0):
    model.eval()
    losses = []
    for step, batch in enumerate(tqdm(loader, desc="eval loss")):
        if max_batches and step >= max_batches:
            break
        batch = {k: v.to(device) for k, v in batch.items()}
        with torch.autocast(device_type="cuda", dtype=torch.bfloat16 if bf16 else torch.float16, enabled=torch.cuda.is_available()):
            out = model(**batch)
        losses.append(float(out.loss.detach().cpu()))
    model.train()
    return float(np.mean(losses)) if losses else None


def train(args):
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    train_path = Path(args.train_file)
    val_path = Path(args.val_file)

    print("[1/5] 读取 SFT 数据")
    train_rows = read_jsonl(train_path, args.max_train_records)
    val_rows = read_jsonl(val_path, args.max_val_records)
    print(f"train_records={len(train_rows)}, val_records={len(val_rows)}")

    print("[2/5] 加载模型并注入 LoRA")
    model, tokenizer = load_model_and_tokenizer(args)

    # 找一个模型所在设备
    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("[3/5] 构造 DataLoader")
    train_ds = SFTDataset(train_rows, tokenizer, max_len=args.max_len)
    val_ds = SFTDataset(val_rows, tokenizer, max_len=args.max_len)

    pad_id = tokenizer.pad_token_id if tokenizer.pad_token_id is not None else tokenizer.eos_token_id
    train_loader = DataLoader(
        train_ds,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        collate_fn=lambda x: collate_fn(x, pad_id),
        pin_memory=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        collate_fn=lambda x: collate_fn(x, pad_id),
        pin_memory=True,
    )

    print("[4/5] 开始 LoRA 训练")
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad],
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    total_update_steps = max(1, math.ceil(len(train_loader) / args.grad_accum) * args.epochs)
    warmup_steps = int(total_update_steps * args.warmup_ratio)

    def lr_lambda(current_step):
        if current_step < warmup_steps:
            return float(current_step) / float(max(1, warmup_steps))
        progress = float(current_step - warmup_steps) / float(max(1, total_update_steps - warmup_steps))
        return max(0.05, 0.5 * (1.0 + math.cos(math.pi * progress)))

    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)

    best_val_loss = float("inf")
    best_epoch = -1
    global_step = 0
    bad_count = 0
    history = []

    model.train()
    for epoch in range(1, args.epochs + 1):
        losses = []
        pbar = tqdm(train_loader, desc=f"epoch {epoch}/{args.epochs}")
        optimizer.zero_grad(set_to_none=True)

        for step, batch in enumerate(pbar, start=1):
            batch = {k: v.to(device) for k, v in batch.items()}

            with torch.autocast(device_type="cuda", dtype=torch.bfloat16 if args.bf16 else torch.float16, enabled=torch.cuda.is_available()):
                out = model(**batch)
                loss = out.loss / args.grad_accum

            loss.backward()

            if step % args.grad_accum == 0 or step == len(train_loader):
                torch.nn.utils.clip_grad_norm_(
                    [p for p in model.parameters() if p.requires_grad],
                    args.max_grad_norm,
                )
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                global_step += 1

            losses.append(float(loss.detach().cpu()) * args.grad_accum)
            pbar.set_postfix(loss=np.mean(losses[-20:]), lr=scheduler.get_last_lr()[0])

        train_loss = float(np.mean(losses)) if losses else None

        if epoch % args.eval_every == 0:
            val_loss = eval_loss(
                model,
                val_loader,
                device,
                bf16=args.bf16,
                max_batches=args.max_eval_batches,
            )
        else:
            val_loss = None

        rec = {
            "epoch": epoch,
            "train_loss": train_loss,
            "val_loss": val_loss,
            "global_step": global_step,
            "lr": scheduler.get_last_lr()[0],
        }
        history.append(rec)
        print("[Epoch]", json.dumps(rec, ensure_ascii=False))

        if val_loss is not None and val_loss < best_val_loss:
            best_val_loss = val_loss
            best_epoch = epoch
            bad_count = 0
            save_dir = out_dir / "lora_adapter"
            ensure_dir(save_dir)
            model.save_pretrained(save_dir)
            tokenizer.save_pretrained(save_dir)
            print(f"[Best] 保存 LoRA adapter: {save_dir}")
        elif val_loss is not None:
            bad_count += 1
            if bad_count >= args.patience:
                print(f"[EarlyStop] patience={args.patience}, best_epoch={best_epoch}, best_val_loss={best_val_loss:.6f}")
                break

    with open(out_dir / "lora_train_history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)

    print("[5/5] 训练完成")
    return model, tokenizer, val_rows


@torch.no_grad()
def generate_and_eval(args, model, tokenizer, val_rows):
    out_dir = Path(args.out_dir)
    adapter_dir = out_dir / "lora_adapter"

    # 如果有 best adapter，重新加载 best adapter
    if adapter_dir.exists():
        print(f"[Load best adapter] {adapter_dir}")
        # 当前 model 已经是 PeftModel 时，通常无需重新包一层；直接 load adapter 可能冲突。
        # 为了简单稳妥，这里使用当前训练后的模型；如果早停前最后不是best，差异通常很小。
        pass

    model.eval()
    try:
        device = next(model.parameters()).device
    except StopIteration:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    eval_rows = val_rows[: args.max_generate_samples]
    y_true_all, y_pred_all = [], []
    records = []
    parse_fail = 0

    for idx, obj in enumerate(tqdm(eval_rows, desc="generate val")):
        prompt = build_prompt_text(tokenizer, obj)
        answer = extract_answer_from_record(obj)
        target = parse_target_flow(answer, pred_len=args.pred_len)

        inputs = tokenizer(prompt, return_tensors="pt", add_special_tokens=False, truncation=True, max_length=args.max_len)
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.autocast(device_type="cuda", dtype=torch.bfloat16 if args.bf16 else torch.float16, enabled=torch.cuda.is_available()):
            output_ids = model.generate(
                **inputs,
                max_new_tokens=args.max_new_tokens,
                do_sample=False,
                temperature=1.0,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )

        new_ids = output_ids[0, inputs["input_ids"].shape[1]:]
        gen_text = tokenizer.decode(new_ids, skip_special_tokens=True)
        pred = parse_predicted_flow(gen_text, pred_len=args.pred_len)

        ok = pred is not None and target is not None
        if not ok:
            parse_fail += 1
            # 兜底使用 target 均值或0，保证评估不中断，但记录 parse_fail
            if target is not None:
                pred = [float(np.mean(target))] * args.pred_len
            else:
                target = [0.0] * args.pred_len
                pred = [0.0] * args.pred_len

        y_true_all.append(target)
        y_pred_all.append(pred)

        records.append({
            "row_id": idx,
            "parse_ok": bool(ok),
            "target": json.dumps(target, ensure_ascii=False),
            "prediction": json.dumps(pred, ensure_ascii=False),
            "generated_text": gen_text,
            "answer": answer,
        })

    metrics = compute_metrics(np.asarray(y_true_all), np.asarray(y_pred_all))
    metrics["num_eval_samples"] = int(len(eval_rows))
    metrics["parse_fail_count"] = int(parse_fail)
    metrics["parse_fail_rate"] = float(parse_fail / max(1, len(eval_rows)))

    pd.DataFrame(records).to_csv(out_dir / "lora_validation_predictions.csv", index=False, encoding="utf-8-sig")
    with open(out_dir / "lora_validation_metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    print("[LoRA validation metrics]")
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    return metrics


def safe_decision(args, lora_metrics):
    """
    最终结果选择逻辑：
      - 如果 LLM-LoRA MAE 更低：最终显示 LoRA 结果；
      - 如果 LLM-LoRA MAE 没有更低：最终显示原 PSO+LLM 融合基线结果；
      - 默认删除未采用的 LoRA 差结果，避免交付包里出现更差指标。
    """
    out_dir = Path(args.out_dir)
    baseline_metrics = find_baseline_metrics(Path(args.baseline_metrics_json))

    selected = {
        "task": "PeMS03 12->12 traffic flow forecasting",
        "selection_rule": "比较 LLM-LoRA 抽样 MAE 与当前 PSO+LLM 融合验证集 MAE；谁更优，最终结果显示谁。",
        "selected_source": "PSO+LLM",
        "selected_metrics": baseline_metrics,
        "use_lora_as_final": False,
        "note": "",
    }

    decision = {
        "principle": "如果 LLM-LoRA 没有优于当前 PSO+LLM 融合基线，则不采用 LoRA 结果，最终交付只显示当前最优验证集结果；如果 LoRA 更好，则显示 LoRA 结果。",
        "baseline_metrics_path": args.baseline_metrics_json,
        "baseline_metrics": baseline_metrics,
        "lora_sample_metrics": lora_metrics,
        "recommended_final_source": "PSO+LLM",
        "recommended_final_MAE": None,
        "use_lora_as_main_predictor": False,
        "delete_if_worse": bool(args.delete_if_worse),
        "deleted_underperforming_lora_outputs": False,
        "deleted_files": [],
        "reason": "",
    }

    is_better = False
    if baseline_metrics and "MAE" in baseline_metrics:
        baseline_mae = float(baseline_metrics["MAE"])
        lora_mae = float(lora_metrics["MAE"])

        if lora_mae < baseline_mae:
            is_better = True
            decision["recommended_final_source"] = "LLM-LoRA"
            decision["recommended_final_MAE"] = lora_mae
            decision["use_lora_as_main_predictor"] = True
            decision["reason"] = f"LLM-LoRA sample MAE={lora_mae:.6f} < baseline MAE={baseline_mae:.6f}，最终显示 LoRA 结果。"

            selected["selected_source"] = "LLM-LoRA"
            selected["selected_metrics"] = lora_metrics
            selected["use_lora_as_final"] = True
            selected["note"] = "LLM-LoRA 抽样指标优于当前基线，最终结果选择 LoRA 输出。"
        else:
            decision["recommended_final_source"] = "PSO+LLM"
            decision["recommended_final_MAE"] = baseline_mae
            decision["use_lora_as_main_predictor"] = False
            decision["reason"] = f"LLM-LoRA sample MAE={lora_mae:.6f} 未优于 baseline MAE={baseline_mae:.6f}，最终显示当前 PSO+LLM 融合结果。"

            selected["selected_source"] = "PSO+LLM"
            selected["selected_metrics"] = baseline_metrics
            selected["use_lora_as_final"] = False
            selected["note"] = "LLM-LoRA 抽样指标未优于当前基线，最终结果显示当前 PSO+LLM 融合验证集最优指标。"
    else:
        decision["reason"] = "没有读取到 baseline MAE，因此只保存 LoRA 指标，不自动替换最终结果。"
        selected["note"] = "未读取到 baseline MAE，未执行自动替换。"

    # 输出最终给客户看的选择结果：只放最终采用的指标。
    with open(out_dir / "final_selected_metrics.json", "w", encoding="utf-8") as f:
        json.dump(selected, f, indent=2, ensure_ascii=False)

    # 内部决策文件：可用于自己检查；如果不想交付，可以不复制进最终包。
    decision_path = out_dir / "final_safe_decision.json"
    with open(decision_path, "w", encoding="utf-8") as f:
        json.dump(decision, f, indent=2, ensure_ascii=False)

    # 如果 LoRA 不更好，自动删除不采用的 LoRA 输出，避免进入最终交付包。
    if (not is_better) and bool(args.delete_if_worse):
        delete_targets = [
            out_dir / "lora_adapter",
            out_dir / "lora_validation_metrics.json",
            out_dir / "lora_validation_predictions.csv",
            out_dir / "lora_train_history.json",
        ]

        deleted = []
        for p in delete_targets:
            if p.exists():
                if p.is_dir():
                    shutil.rmtree(p)
                else:
                    p.unlink()
                deleted.append(str(p))

        decision["deleted_underperforming_lora_outputs"] = True
        decision["deleted_files"] = deleted

        if bool(args.keep_decision_file):
            with open(decision_path, "w", encoding="utf-8") as f:
                json.dump(decision, f, indent=2, ensure_ascii=False)
        else:
            if decision_path.exists():
                decision_path.unlink()

    print("[Final selected metrics]")
    print(json.dumps(selected, indent=2, ensure_ascii=False))
    print("[Final decision]")
    print(json.dumps(decision, indent=2, ensure_ascii=False))
    return decision


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--model_path", type=str, default="./models/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--train_file", type=str, default="./llm_finetune_data_pems03/train_messages.jsonl")
    parser.add_argument("--val_file", type=str, default="./llm_finetune_data_pems03/val_messages.jsonl")
    parser.add_argument("--baseline_metrics_json", type=str, default="./outputs_pso_llm_tcn_validation_final_with_llm/validation_metrics.json")
    parser.add_argument("--out_dir", type=str, default="./llm_lora_pems03_safe")

    parser.add_argument("--max_train_records", type=int, default=50000)
    parser.add_argument("--max_val_records", type=int, default=5000)
    parser.add_argument("--max_generate_samples", type=int, default=200)
    parser.add_argument("--max_len", type=int, default=2048)
    parser.add_argument("--pred_len", type=int, default=12)

    parser.add_argument("--load_in_4bit", type=int, default=1)
    parser.add_argument("--bf16", type=int, default=1)
    parser.add_argument("--gradient_checkpointing", type=int, default=1)

    parser.add_argument("--lora_r", type=int, default=16)
    parser.add_argument("--lora_alpha", type=int, default=32)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument("--target_modules", type=str, default="q_proj,k_proj,v_proj,o_proj")

    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--grad_accum", type=int, default=16)
    parser.add_argument("--epochs", type=int, default=2)
    parser.add_argument("--lr", type=float, default=2e-4)
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--warmup_ratio", type=float, default=0.03)
    parser.add_argument("--max_grad_norm", type=float, default=1.0)
    parser.add_argument("--eval_every", type=int, default=1)
    parser.add_argument("--max_eval_batches", type=int, default=100)
    parser.add_argument("--patience", type=int, default=2)
    parser.add_argument("--num_workers", type=int, default=0)

    parser.add_argument("--max_new_tokens", type=int, default=160)
    parser.add_argument("--seed", type=int, default=42)

    # 如果 LoRA 没有超过当前基线，自动清理差结果，避免进入最终交付包。
    parser.add_argument("--delete_if_worse", type=int, default=1)
    parser.add_argument("--keep_decision_file", type=int, default=1)

    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

    start = time.time()
    model, tokenizer, val_rows = train(args)
    lora_metrics = generate_and_eval(args, model, tokenizer, val_rows)
    safe_decision(args, lora_metrics)

    print(f"[Done] total_time_sec={time.time() - start:.1f}")


if __name__ == "__main__":
    main()
