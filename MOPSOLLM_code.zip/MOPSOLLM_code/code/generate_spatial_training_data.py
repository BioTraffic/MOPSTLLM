#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 Top-K 空间增强的 LLM 训练/验证 messages 数据。"""
import argparse
from spatial_llm_pipeline import cmd_generate


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--data_dir', required=True)
    p.add_argument('--raw_csv', required=True)
    p.add_argument('--pso_weights', required=True)
    p.add_argument('--out_dir', required=True)
    p.add_argument('--compact_prompt', type=int, default=1)
    p.add_argument('--top_k', type=int, default=5)
    p.add_argument('--similarity_method', default='pearson', choices=['pearson', 'cosine'])
    p.add_argument('--tau', type=float, default=0.1)
    p.add_argument('--beta', default='auto')
    p.add_argument('--beta_search_pairs', type=int, default=5000)
    p.add_argument('--max_train_samples', type=int, default=100000)
    p.add_argument('--max_val_samples', type=int, default=20000)
    p.add_argument('--round_ndigits', type=int, default=3)
    p.add_argument('--seed', type=int, default=42)
    args = p.parse_args()
    cmd_generate(args)


if __name__ == '__main__':
    main()
