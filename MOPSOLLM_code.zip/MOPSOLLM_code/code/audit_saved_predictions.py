#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""审计旧版验证CSV：重算误差、严格检查 LLM 生成、给出可复现基线。"""
import argparse, csv, json, math
from pathlib import Path
import numpy as np


def arr(s):
    a = np.array(json.loads(s), dtype=np.float64)
    if a.shape != (12,) or not np.all(np.isfinite(a)):
        raise ValueError("预测列不是有效12步序列")
    return a


def strict_reply_only(s, target):
    # 旧CSV错误地混进整个 prompt。仅检查 assistant 生成部分；不会修补模型生成内容。
    if "assistant\n\n" in s:
        s = s.rsplit("assistant\n\n", 1)[-1]
    try:
        obj = json.loads(s.strip())
        val = obj["predicted_flow"]
        if set(obj) != {"sensor_id", "predicted_flow"}: return None
        if obj["sensor_id"] != f"sensor_{target}": return None
        if not isinstance(val,list) or len(val)!=12: return None
        if not all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in val):return None
        return np.array(val,dtype=np.float64)
    except Exception:
        return None


def prompt_data(s):
    prefix='user\n\n'
    i=s.find(prefix)
    if i<0: return None
    try:
        return json.JSONDecoder().raw_decode(s[i+len(prefix):])[0]
    except Exception:
        return None


def calc(ys,ps,max_val=None):
    y=np.stack(ys);p=np.stack(ps)
    mse=np.mean((y-p)**2)
    d={'MAE':float(np.abs(y-p).mean()),'RMSE':float(np.sqrt(mse)),'MSE':float(mse)}
    if max_val is not None:
        d['PSNR_dB']=float(10*math.log10(max_val**2/mse)) if mse else None
        d['PSNR_peak_def']=f'user_supplied_{max_val}'
    return d


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--predictions_csv',required=True)
    p.add_argument('--out_json',required=True)
    p.add_argument('--psnr_peak',type=float,default=None,
                   help='只在评测协议明确给定峰值时指定，不能随意用255')
    args=p.parse_args()
    with open(args.predictions_csv,encoding='utf-8',newline='') as f: rows=list(csv.DictReader(f))
    Y=[]; legacy=[]; PSO=[]; SP=[]; spatial_agg=[]; llm_y=[]; llm_pred=[]
    for r in rows:
        y=arr(r['y_true']); Y.append(y)
        if 'y_pred' in r: legacy.append(arr(r['y_pred']))
        d=prompt_data(r['raw_output'])
        if d is not None:
            PSO.append(arr(json.dumps(d['目标节点PSO融合预测'])))
            SP.append(arr(json.dumps(d['空间增强预测'])))
            spatial_agg.append(arr(json.dumps(d['空间聚合预测'])))
        out=strict_reply_only(r['raw_output'],int(r['sensor_id']))
        if out is not None:
            llm_y.append(y);llm_pred.append(out)
    report={
        'num_samples':len(rows),'num_strict_valid_llm':len(llm_pred),
        'strict_llm_valid_fraction':len(llm_pred)/len(rows) if rows else 0,
        'legacy_extracted_numbers':calc(Y,legacy,args.psnr_peak) if len(legacy)==len(Y) and Y else None,
        'pso':calc(Y,PSO,args.psnr_peak) if len(PSO)==len(Y) and Y else None,
        'spatial':calc(Y,SP,args.psnr_peak) if len(SP)==len(Y) and Y else None,
        'neighbors_direct':calc(Y,spatial_agg,args.psnr_peak) if len(spatial_agg)==len(Y) and Y else None,
        'valid_subset_llm_not_comparable':calc(llm_y,llm_pred,args.psnr_peak) if llm_pred else None,
        'model_all_samples_MAE':calc(Y,llm_pred,args.psnr_peak)['MAE'] if len(llm_pred)==len(Y) and Y else None,
        'target_MAE':14,
        'target_met_by_valid_llm':bool(len(llm_pred)==len(Y) and Y and calc(Y,llm_pred)['MAE']<14),
    }
    Path(args.out_json).parent.mkdir(parents=True,exist_ok=True)
    Path(args.out_json).write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
