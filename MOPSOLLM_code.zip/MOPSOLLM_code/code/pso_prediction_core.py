#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py

增强版 PSO + LLM v7_final_trainval，按客户要求的 PeMS03 12→12 数据逻辑：
  第1个样本：X=1-12，Y=13-24
  第2个样本：X=2-13，Y=14-25
  ...

相比 v2 增强：
  1. 候选预测器加入“前一天差分修正”和“前一天比例修正”；
  2. 加入前一周差分修正；
  3. PSO 同时优化历史时间步权重与候选预测融合权重；
  4. 仍然不依赖额外循环或卷积残差模块，保持 PSO+LLM 主方案；
  5. 新增训练集“传感器-日内时段历史画像”候选：
       profile_mean / profile_median / profile_ratio；
  6. LLM 只做轻量修正，最终用门控融合，避免数值被带偏。

快速验证：
  python train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py --max_pso_samples 10000 --max_eval_pairs 10000 --run_llm 0 --pso_iters 60

正式运行：
  python train_pso_llm_xy_12to12_v7_final_trainval_fixed2.py --max_pso_samples 80000 --max_eval_pairs 80000 --pso_particles 80 --pso_iters 120 --run_llm 1 --max_llm_samples 100
"""

import argparse
import json
import math
import random
import re
import time
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

import torch
import torch.nn as nn


SEQ_LEN = 12
PRED_LEN = 12
N_SENSOR = 358
DAY_STEPS = 288
WEEK_STEPS = 2016

CANDIDATE_NAMES = [
    "last_repeat",
    "weighted_linear",
    "weighted_mean",
    "recent_delta",
    "previous_day",
    "previous_day_delta",
    "previous_day_ratio",
    "previous_week",
    "previous_week_delta",
    "day_week_blend",
    "profile_mean",
    "profile_median",
    "profile_ratio",
    "analog_same_tod",
    "analog_profile_blend",
]


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)


def ensure_dir(p: Path):
    p.mkdir(parents=True, exist_ok=True)


def load_npy(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"找不到文件: {path}")
    return np.load(path, mmap_mode="r")


def load_index(path: Path):
    if not path.exists():
        raise FileNotFoundError(f"找不到索引文件: {path}")
    df = pd.read_csv(path)
    if "target_start_row_1based" not in df.columns:
        if "input_start_row_1based" in df.columns:
            df["target_start_row_1based"] = df["input_start_row_1based"] + SEQ_LEN
        elif "start" in df.columns:
            df["target_start_row_1based"] = df["start"] + SEQ_LEN + 1
        else:
            raise ValueError(f"{path} 缺少窗口起点字段")
    return df


def load_raw_csv(path: Path):
    if not path.exists():
        print(f"[WARN] 找不到原始CSV，周期候选将退化: {path}")
        return None
    print(f"[Load raw CSV] {path}")
    return pd.read_csv(path, header=None).values.astype(np.float32)


def infer_train_end_from_index(train_index: pd.DataFrame) -> int:
    """
    根据 train_index 推断训练片段在原始序列中的结束行号。
    返回 0-based 切片终点，即 raw[:train_end]。
    """
    if "target_end_row_1based" in train_index.columns:
        return int(train_index["target_end_row_1based"].max())
    if "target_start_row_1based" in train_index.columns:
        return int(train_index["target_start_row_1based"].max() + PRED_LEN - 1)
    if "input_end_row_1based" in train_index.columns:
        return int(train_index["input_end_row_1based"].max() + PRED_LEN)
    raise ValueError("无法从 train_index 推断训练集结束位置。")


def build_time_of_day_profile(raw: np.ndarray, train_end: int):
    """
    只用训练集 raw[:train_end] 统计每个传感器在一天288个5分钟时段上的均值/中位数画像。
    这样不会使用验证集/测试集信息，避免数据泄露。

    返回：
      profile_mean:   [288, 358]
      profile_median: [288, 358]
    """
    if raw is None:
        return None

    train_part = raw[:train_end].astype(np.float32)
    if train_part.shape[0] < DAY_STEPS:
        print("[WARN] 训练集长度不足一天，profile候选将退化。")
        return None

    n_sensor = train_part.shape[1]
    profile_mean = np.zeros((DAY_STEPS, n_sensor), dtype=np.float32)
    profile_median = np.zeros((DAY_STEPS, n_sensor), dtype=np.float32)

    global_mean = train_part.mean(axis=0).astype(np.float32)
    global_median = np.median(train_part, axis=0).astype(np.float32)

    for tod in range(DAY_STEPS):
        vals = train_part[tod::DAY_STEPS, :]
        if vals.shape[0] == 0:
            profile_mean[tod] = global_mean
            profile_median[tod] = global_median
        else:
            profile_mean[tod] = vals.mean(axis=0)
            profile_median[tod] = np.median(vals, axis=0)

    profile = {
        "mean": profile_mean,
        "median": profile_median,
        "global_mean": global_mean,
        "global_median": global_median,
        "train_end": int(train_end),
    }
    print(f"[Profile] built from raw[:{train_end}], profile_mean={profile_mean.shape}")
    return profile


def get_profile_future(profile, target_start_0based, sensor_ids, fallback):
    """
    根据未来12步的全局 time-of-day 获取 profile_mean/profile_median 候选。
    """
    if profile is None:
        return fallback.copy(), fallback.copy(), fallback.copy()

    tod = (target_start_0based.reshape(-1, 1) + np.arange(PRED_LEN).reshape(1, -1)) % DAY_STEPS
    sensor_mat = sensor_ids.reshape(-1, 1)

    prof_mean = profile["mean"][tod, sensor_mat].astype(np.float32)
    prof_median = profile["median"][tod, sensor_mat].astype(np.float32)

    # 当前最后一个历史点对应的 time-of-day，用于比例修正
    current_last_tod = (target_start_0based - 1) % DAY_STEPS
    current_profile = profile["mean"][current_last_tod, sensor_ids].astype(np.float32)
    # ratio由当前真实last和该时段历史画像决定，外部传hist传入后修正
    return prof_mean, prof_median, current_profile


def analog_same_tod_candidate(raw, train_end, hist, target_start_0based, sensor_ids, fallback, max_candidates=80, top_k=5):
    """
    历史相似日候选：
    对于当前样本的未来起点 target_start_0based，找训练集中相同 time-of-day 的历史样本。
    用当前历史12步 hist 与训练集中对应历史12步做距离匹配，取 top_k 个最相似样本的未来12步均值。

    只检索 raw[:train_end]，不使用验证集/测试集，避免数据泄露。
    """
    if raw is None or train_end is None or train_end <= SEQ_LEN + PRED_LEN:
        return fallback.copy()

    hist = np.asarray(hist, dtype=np.float32)
    n = hist.shape[0]
    out = fallback.copy().astype(np.float32)

    for i in range(n):
        sensor = int(sensor_ids[i])
        tod = int(target_start_0based[i] % DAY_STEPS)

        # 候选未来起点 m 必须满足：
        # 1) m 的 time-of-day 相同；
        # 2) m-12:m 与 m:m+12 都在训练集内；
        # 3) 严格只能使用当前样本之前的历史候选，避免训练阶段把自己的Y当作候选直接取出来。
        #
        # 原 v4 的问题：
        #   对训练样本而言，candidate_m 可能等于当前 target_start_0based[i]，
        #   这样 cand_hist 与当前 hist 完全相同，cand_future 就等于当前 target，
        #   属于标签泄露，会导致训练 MAE 虚假下降到 1.x。
        #
        # 修复：
        #   candidate_m <= target_start_0based[i] - PRED_LEN
        #   保证候选未来窗口结束时间早于当前预测目标起点。
        candidate_m = np.arange(tod, train_end - PRED_LEN + 1, DAY_STEPS, dtype=np.int64)
        candidate_m = candidate_m[candidate_m >= SEQ_LEN]
        candidate_m = candidate_m[candidate_m <= int(target_start_0based[i]) - PRED_LEN]
        if candidate_m.size == 0:
            continue

        # 为了速度，最多保留最近 max_candidates 个训练候选
        if candidate_m.size > max_candidates:
            candidate_m = candidate_m[-max_candidates:]

        # [C,12]
        cand_hist = np.stack([raw[m - SEQ_LEN:m, sensor] for m in candidate_m], axis=0).astype(np.float32)
        cand_future = np.stack([raw[m:m + PRED_LEN, sensor] for m in candidate_m], axis=0).astype(np.float32)

        # 标准化距离，避免大流量sensor距离偏大
        scale = np.std(cand_hist) + 1.0
        dist = np.mean(np.abs((cand_hist - hist[i].reshape(1, -1)) / scale), axis=1)

        k = min(top_k, len(dist))
        ids = np.argsort(dist)[:k]

        # 距离越小权重越大
        w = 1.0 / (dist[ids] + 1e-3)
        w = w / np.sum(w)

        out[i] = np.sum(cand_future[ids] * w.reshape(-1, 1), axis=0)

    return np.maximum(out, 0.0).astype(np.float32)


def normalize_positive(v):
    v = np.asarray(v, dtype=np.float64)
    v = np.maximum(v, 1e-8)
    return v / np.sum(v)


def decode_particle(particle):
    particle = np.asarray(particle, dtype=np.float64)
    time_w = normalize_positive(particle[:SEQ_LEN]).astype(np.float32)
    cand_w = normalize_positive(particle[SEQ_LEN:SEQ_LEN + len(CANDIDATE_NAMES)]).astype(np.float32)
    return time_w, cand_w


def compute_metrics(y_true, y_pred, mask_threshold=5.0):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    err = y_pred - y_true

    mae = float(np.mean(np.abs(err)))
    rmse = float(math.sqrt(np.mean(err ** 2)))

    mask = y_true > mask_threshold
    if np.any(mask):
        masked_mae = float(np.mean(np.abs(y_pred[mask] - y_true[mask])))
        masked_rmse = float(math.sqrt(np.mean((y_pred[mask] - y_true[mask]) ** 2)))
        masked_mape = float(np.mean(np.abs((y_pred[mask] - y_true[mask]) / y_true[mask])) * 100.0)
    else:
        masked_mae = float("nan")
        masked_rmse = float("nan")
        masked_mape = float("nan")

    peak_true = np.max(y_true, axis=1)
    peak_pred = np.max(y_pred, axis=1)
    peak_mae = float(np.mean(np.abs(peak_pred - peak_true)))

    return {
        "MAE": mae,
        "RMSE": rmse,
        "Masked_MAE": masked_mae,
        "Masked_RMSE": masked_rmse,
        "Masked_MAPE_percent": masked_mape,
        "Peak_MAE": peak_mae,
    }


def fitness(y_true, y_pred):
    m = compute_metrics(y_true, y_pred, mask_threshold=5.0)
    return 0.75 * m["MAE"] + 0.15 * m["RMSE"] + 0.10 * m["Peak_MAE"]


def sample_pairs(X, Y, index_df, max_pairs=50000, seed=42):
    rng = np.random.default_rng(seed)
    n_sample = X.shape[0]
    n_sensor = X.shape[2]
    total_pairs = n_sample * n_sensor

    if max_pairs <= 0 or max_pairs >= total_pairs:
        if total_pairs > 2000000:
            pair_ids = rng.choice(total_pairs, size=2000000, replace=False).astype(np.int64)
        else:
            pair_ids = np.arange(total_pairs, dtype=np.int64)
    else:
        pair_ids = rng.choice(total_pairs, size=int(max_pairs), replace=False).astype(np.int64)

    sample_ids = pair_ids // n_sensor
    sensor_ids = pair_ids % n_sensor
    target_start_1based = index_df["target_start_row_1based"].values.astype(np.int64)
    target_start_0based = target_start_1based[sample_ids] - 1
    return sample_ids.astype(np.int64), sensor_ids.astype(np.int64), target_start_0based.astype(np.int64)


def gather_xy(X, Y, sample_ids, sensor_ids):
    hist = X[sample_ids, :, sensor_ids].astype(np.float32)
    target = Y[sample_ids, :, sensor_ids].astype(np.float32)
    return hist, target


def get_raw_future(raw, target_start_0based, sensor_ids, lag_steps, fallback):
    if raw is None:
        return fallback.copy(), np.zeros_like(fallback, dtype=np.float32)

    pos = target_start_0based.reshape(-1, 1) - lag_steps + np.arange(PRED_LEN).reshape(1, -1)
    valid = np.all((pos >= 0) & (pos < raw.shape[0]), axis=1)

    out = fallback.copy()
    mask = np.zeros_like(fallback, dtype=np.float32)
    if np.any(valid):
        idx = np.where(valid)[0]
        out[idx] = raw[pos[idx], sensor_ids[idx].reshape(-1, 1)]
        mask[idx] = 1.0
    return out.astype(np.float32), mask


def get_raw_point(raw, point_0based, sensor_ids, fallback_1d):
    if raw is None:
        return fallback_1d.copy(), np.zeros_like(fallback_1d, dtype=np.float32)

    valid = (point_0based >= 0) & (point_0based < raw.shape[0])
    out = fallback_1d.copy()
    mask = np.zeros_like(fallback_1d, dtype=np.float32)
    if np.any(valid):
        idx = np.where(valid)[0]
        out[idx] = raw[point_0based[idx], sensor_ids[idx]]
        mask[idx] = 1.0
    return out.astype(np.float32), mask


def build_candidates(hist, time_w, raw, target_start_0based, sensor_ids, profile=None, train_end=None):
    hist = np.asarray(hist, dtype=np.float32)
    n = hist.shape[0]
    w = normalize_positive(time_w).astype(np.float32).reshape(1, -1)

    # 1. 最近值延续
    last_repeat = np.repeat(hist[:, -1:].copy(), PRED_LEN, axis=1)

    # 2. 加权线性趋势
    x = np.arange(SEQ_LEN, dtype=np.float32).reshape(1, -1)
    x_bar = np.sum(w * x, axis=1, keepdims=True)
    y_bar = np.sum(w * hist, axis=1, keepdims=True)
    denom = np.sum(w * (x - x_bar) ** 2, axis=1, keepdims=True) + 1e-6
    slope = np.sum(w * (x - x_bar) * (hist - y_bar), axis=1, keepdims=True) / denom
    future = np.arange(1, PRED_LEN + 1, dtype=np.float32).reshape(1, -1)
    weighted_linear = np.maximum(hist[:, -1:].copy() + slope * future, 0.0)

    # 3. 加权均值
    weighted_mean = np.repeat(y_bar, PRED_LEN, axis=1)

    # 4. 近期差分趋势
    recent_slope = np.mean(np.diff(hist[:, -4:], axis=1), axis=1, keepdims=True)
    recent_delta = np.maximum(hist[:, -1:].copy() + recent_slope * future, 0.0)

    # 5. 前一天同时间段
    previous_day, day_mask = get_raw_future(raw, target_start_0based, sensor_ids, DAY_STEPS, last_repeat)

    # 前一天输入窗口最后一个点：对应当前hist[-1]的昨日同位置
    current_last_global = target_start_0based - 1
    prev_day_last, day_last_mask = get_raw_point(
        raw, current_last_global - DAY_STEPS, sensor_ids, hist[:, -1].copy()
    )

    # 6. 前一天差分修正：昨日未来 + 当前最后值 - 昨日最后值
    delta_day = (hist[:, -1] - prev_day_last).reshape(-1, 1)
    previous_day_delta = previous_day + delta_day
    previous_day_delta = np.maximum(previous_day_delta, 0.0)

    # 7. 前一天比例修正：昨日未来 * 当前最后值 / 昨日最后值
    ratio_day = hist[:, -1] / np.maximum(prev_day_last, 5.0)
    ratio_day = np.clip(ratio_day, 0.5, 1.8).reshape(-1, 1)
    previous_day_ratio = np.maximum(previous_day * ratio_day, 0.0)

    # 8. 前一周同时间段
    previous_week, week_mask = get_raw_future(raw, target_start_0based, sensor_ids, WEEK_STEPS, previous_day)

    # 前一周最后点
    prev_week_last, week_last_mask = get_raw_point(
        raw, current_last_global - WEEK_STEPS, sensor_ids, prev_day_last.copy()
    )

    # 9. 前一周差分修正
    delta_week = (hist[:, -1] - prev_week_last).reshape(-1, 1)
    previous_week_delta = np.maximum(previous_week + delta_week, 0.0)

    # 10. 日周融合，周不可用时基本退化到日
    day_week_blend = 0.75 * previous_day_delta + 0.25 * previous_week_delta

    # 11-13. 训练集日内时段画像候选：不使用验证/测试统计，避免数据泄露
    prof_mean, prof_median, current_profile = get_profile_future(
        profile, target_start_0based, sensor_ids, fallback=previous_day_delta
    )
    ratio_profile = hist[:, -1] / np.maximum(current_profile, 5.0)
    ratio_profile = np.clip(ratio_profile, 0.5, 1.8).reshape(-1, 1)
    profile_ratio = np.maximum(prof_mean * ratio_profile, 0.0)

    # 14. 历史相似日候选：同一日内时段下，匹配训练集中最相似的历史12步，取其未来12步
    analog_same_tod = analog_same_tod_candidate(
        raw, train_end, hist, target_start_0based, sensor_ids,
        fallback=profile_ratio,
        max_candidates=80,
        top_k=5
    )

    # 15. 相似日与画像融合候选
    analog_profile_blend = 0.65 * analog_same_tod + 0.35 * profile_ratio

    candidates = np.stack([
        last_repeat,
        weighted_linear,
        weighted_mean,
        recent_delta,
        previous_day,
        previous_day_delta,
        previous_day_ratio,
        previous_week,
        previous_week_delta,
        day_week_blend,
        prof_mean,
        prof_median,
        profile_ratio,
        analog_same_tod,
        analog_profile_blend,
    ], axis=1).astype(np.float32)

    # 异常范围约束：避免某些ratio导致极端值
    local_max = np.maximum(np.max(hist, axis=1, keepdims=True), 1.0)
    upper = local_max.reshape(-1, 1, 1) * 2.2 + 100.0
    candidates = np.clip(candidates, 0.0, upper)
    return candidates


def fuse_candidates(candidates, cand_w):
    cand_w = normalize_positive(cand_w).astype(np.float32).reshape(1, -1, 1)
    return np.sum(candidates * cand_w, axis=1).astype(np.float32)


def pso_predict(hist, target_start_0based, sensor_ids, particle, raw, profile=None, train_end=None):
    time_w, cand_w = decode_particle(particle)
    candidates = build_candidates(hist, time_w, raw, target_start_0based, sensor_ids, profile=profile, train_end=train_end)
    return fuse_candidates(candidates, cand_w)


def train_pso(hist, target, target_start_0based, sensor_ids, raw, profile=None, train_end=None, particles=80, iters=120, seed=42):
    rng = np.random.default_rng(seed)
    dim = SEQ_LEN + len(CANDIDATE_NAMES)

    positions = rng.random((particles, dim)).astype(np.float64)
    velocities = rng.normal(0, 0.05, size=(particles, dim)).astype(np.float64)

    recency = np.linspace(0.5, 1.8, SEQ_LEN)

    priors = [
        # 强历史相似日
        [0.015, 0.025, 0.01, 0.025, 0.04, 0.08, 0.05, 0.015, 0.015, 0.025, 0.08, 0.03, 0.12, 0.38, 0.10],
        # 相似日+profile融合
        [0.015, 0.025, 0.01, 0.025, 0.04, 0.08, 0.05, 0.015, 0.015, 0.025, 0.08, 0.03, 0.12, 0.12, 0.38],
        # 强profile比例
        [0.02, 0.03, 0.01, 0.03, 0.05, 0.10, 0.08, 0.02, 0.02, 0.03, 0.10, 0.05, 0.32, 0.10, 0.04],
        # 强前一天差分
        [0.02, 0.04, 0.01, 0.04, 0.08, 0.34, 0.08, 0.02, 0.02, 0.03, 0.08, 0.03, 0.08, 0.10, 0.05],
        # 强前一天比例
        [0.02, 0.04, 0.01, 0.04, 0.06, 0.12, 0.32, 0.02, 0.02, 0.02, 0.08, 0.03, 0.10, 0.10, 0.04],
        # 日周融合
        [0.02, 0.04, 0.01, 0.04, 0.08, 0.18, 0.06, 0.03, 0.05, 0.16, 0.10, 0.03, 0.06, 0.10, 0.08],
        # 最近趋势
        [0.18, 0.20, 0.04, 0.24, 0.03, 0.03, 0.02, 0.01, 0.005, 0.005, 0.08, 0.02, 0.03, 0.08, 0.04],
    ]
    for i, prior in enumerate(priors):
        if i < particles:
            positions[i, :SEQ_LEN] = recency
            positions[i, SEQ_LEN:] = np.array(prior, dtype=np.float64)

    pbest_pos = positions.copy()
    pbest_score = np.full(particles, np.inf)
    gbest_pos = None
    gbest_score = np.inf
    history = []

    for it in range(1, iters + 1):
        for i in range(particles):
            pred = pso_predict(hist, target_start_0based, sensor_ids, positions[i], raw, profile=profile, train_end=train_end)
            score = fitness(target, pred)
            if score < pbest_score[i]:
                pbest_score[i] = score
                pbest_pos[i] = positions[i].copy()
            if score < gbest_score:
                gbest_score = score
                gbest_pos = positions[i].copy()

        best_pred = pso_predict(hist, target_start_0based, sensor_ids, gbest_pos, raw, profile=profile, train_end=train_end)
        metrics = compute_metrics(target, best_pred, mask_threshold=5.0)
        time_w, cand_w = decode_particle(gbest_pos)
        item = {
            "iter": it,
            "fitness": float(gbest_score),
            **metrics,
            "time_weights": [float(x) for x in time_w],
            "candidate_weights": {name: float(w) for name, w in zip(CANDIDATE_NAMES, cand_w)},
        }
        history.append(item)

        print(
            f"[PSO-v7] {it:03d}/{iters} "
            f"fitness={gbest_score:.4f} MAE={metrics['MAE']:.4f} "
            f"RMSE={metrics['RMSE']:.4f} MAPE={metrics['Masked_MAPE_percent']:.2f}% "
            f"Peak_MAE={metrics['Peak_MAE']:.4f}"
        )

        inertia, c1, c2 = 0.72, 1.45, 1.45
        r1 = rng.random((particles, dim))
        r2 = rng.random((particles, dim))
        velocities = (
            inertia * velocities
            + c1 * r1 * (pbest_pos - positions)
            + c2 * r2 * (gbest_pos.reshape(1, -1) - positions)
        )
        positions = np.clip(positions + velocities, 1e-6, 5.0)

    return gbest_pos, history


def evaluate_pso(X, Y, index_df, raw, profile, train_end, particle, max_pairs=50000, seed=123, save_pred_path=None):
    sample_ids, sensor_ids, target_start = sample_pairs(X, Y, index_df, max_pairs=max_pairs, seed=seed)
    hist, target = gather_xy(X, Y, sample_ids, sensor_ids)
    pred = pso_predict(hist, target_start, sensor_ids, particle, raw, profile=profile, train_end=train_end)
    pred = np.maximum(pred, 0.0)
    metrics = compute_metrics(target, pred, mask_threshold=5.0)

    if save_pred_path is not None:
        rows = []
        n = min(len(sample_ids), 5000)
        for i in range(n):
            rows.append({
                "sample_id": int(sample_ids[i]),
                "sensor_id": int(sensor_ids[i]),
                "target_start_0based": int(target_start[i]),
                "history": json.dumps([round(float(x), 4) for x in hist[i].tolist()], ensure_ascii=False),
                "target": json.dumps([round(float(x), 4) for x in target[i].tolist()], ensure_ascii=False),
                "pso_prediction": json.dumps([round(float(x), 4) for x in pred[i].tolist()], ensure_ascii=False),
                "mae": float(np.mean(np.abs(pred[i] - target[i]))),
            })
        pd.DataFrame(rows).to_csv(save_pred_path, index=False, encoding="utf-8-sig")
    return metrics


def save_curve(history, out_dir):
    try:
        import matplotlib.pyplot as plt
        iters = [x["iter"] for x in history]
        fit = [x["fitness"] for x in history]
        mae = [x["MAE"] for x in history]
        rmse = [x["RMSE"] for x in history]

        plt.figure()
        plt.plot(iters, fit, label="Fitness")
        plt.xlabel("Iteration")
        plt.ylabel("Fitness")
        plt.title("PSO-v5 Optimization Curve")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "pso_optimization_curve.png", dpi=200)
        plt.close()

        plt.figure()
        plt.plot(iters, mae, label="MAE")
        plt.plot(iters, rmse, label="RMSE")
        plt.xlabel("Iteration")
        plt.ylabel("Error")
        plt.title("PSO-v5 Error Curve")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_dir / "pso_error_curve.png", dpi=200)
        plt.close()
    except Exception as e:
        print(f"[WARN] 绘图失败: {repr(e)}")


def find_peak_steps(seq):
    seq = np.asarray(seq, dtype=float)
    th = np.quantile(seq, 0.85)
    ids = np.where(seq >= th)[0].tolist()
    return [f"t-{len(seq) - i}" for i in ids]


def trend_text(seq):
    seq = np.asarray(seq, dtype=float)
    diff = seq[-1] - seq[0]
    max_i = int(np.argmax(seq)) + 1
    min_i = int(np.argmin(seq)) + 1
    if diff > max(5.0, 0.1 * max(abs(seq[0]), 1.0)):
        main = "整体呈上升趋势"
    elif diff < -max(5.0, 0.1 * max(abs(seq[0]), 1.0)):
        main = "整体呈下降趋势"
    else:
        main = "整体相对平稳"
    return f"{main}，最大值出现在历史第{max_i}个时间步，最小值出现在历史第{min_i}个时间步。"


def build_llm_prompt(sensor_id, hist, pso_pred, candidates, time_w, cand_w):
    cand_obj = {name: [round(float(x), 3) for x in arr.tolist()]
                for name, arr in zip(CANDIDATE_NAMES, candidates)}

    prompt = f"""
你是一个交通流量预测模型。请根据历史交通流量、PSO权重、候选预测结果、峰值时刻和趋势描述，预测未来12个时间步交通流量。

要求：
1. 只输出JSON，不要解释。
2. predicted_flow必须是长度为12的数字数组。
3. 预测值必须非负。
4. PSO融合预测是主要数值参考，只允许小幅修正。
5. 避免不合理突变。

传感器编号：sensor_{sensor_id}

历史12步流量：
{[round(float(x), 3) for x in hist.tolist()]}

PSO时间步权重：
{[round(float(x), 5) for x in time_w.tolist()]}

PSO候选融合权重：
{ {name: round(float(w), 5) for name, w in zip(CANDIDATE_NAMES, cand_w)} }

候选预测结果：
{json.dumps(cand_obj, ensure_ascii=False)}

PSO融合预测：
{[round(float(x), 3) for x in pso_pred.tolist()]}

峰值时间步：
{find_peak_steps(hist)}

历史趋势：
{trend_text(hist)}

输出格式：
{{"sensor_id":"sensor_{sensor_id}","predicted_flow":[数值1,数值2,数值3,数值4,数值5,数值6,数值7,数值8,数值9,数值10,数值11,数值12]}}
""".strip()
    return prompt


def parse_pred(text):
    try:
        s = text.find("{")
        e = text.rfind("}")
        if s >= 0 and e > s:
            obj = json.loads(text[s:e+1])
            arr = obj.get("predicted_flow")
            if arr is not None and len(arr) >= PRED_LEN:
                return np.array([float(x) for x in arr[:PRED_LEN]], dtype=np.float32)
    except Exception:
        pass

    m = re.search(r'"?predicted_flow"?\s*:\s*\[([^\]]+)\]', text)
    if m:
        nums = re.findall(r"-?\d+(?:\.\d+)?", m.group(1))
        if len(nums) >= PRED_LEN:
            return np.array([float(x) for x in nums[:PRED_LEN]], dtype=np.float32)

    nums = re.findall(r"-?\d+(?:\.\d+)?", text)
    if len(nums) >= PRED_LEN:
        return np.array([float(x) for x in nums[-PRED_LEN:]], dtype=np.float32)
    return None


def load_llama(model_path):
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM

    print(f"[LLM] Loading tokenizer: {model_path}")
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    print(f"[LLM] Loading model: {model_path}")
    try:
        model = AutoModelForCausalLM.from_pretrained(model_path, dtype=torch.float16, device_map="auto")
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=torch.float16, device_map="auto")
    model.eval()
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    return tokenizer, model


def llama_generate(tokenizer, model, prompt, max_new_tokens=160):
    import torch
    messages = [
        {"role": "system", "content": "你是严谨的交通流量预测助手，只输出JSON。"},
        {"role": "user", "content": prompt},
    ]
    text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    inputs = tokenizer(text, return_tensors="pt").to(model.device)
    with torch.no_grad():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            pad_token_id=tokenizer.eos_token_id,
        )
    result = tokenizer.decode(outputs[0], skip_special_tokens=True)
    if "assistant" in result:
        result = result.split("assistant")[-1]
    return result.strip()


def evaluate_llm(X, Y, index_df, raw, profile, train_end, particle, out_dir, model_path, max_llm_samples=50, seed=999):
    sample_ids, sensor_ids, target_start = sample_pairs(X, Y, index_df, max_pairs=max_llm_samples, seed=seed)
    hist, target = gather_xy(X, Y, sample_ids, sensor_ids)
    time_w, cand_w = decode_particle(particle)

    tokenizer, model = load_llama(model_path)

    prompt_f = open(out_dir / "llm_prompt_examples.jsonl", "w", encoding="utf-8")
    rows = []
    y_true_all, y_pso_all, y_llm_all, y_final_all = [], [], [], []
    fusion_count = 0
    fallback_count = 0

    for i in tqdm(range(len(sample_ids)), desc="LLM evaluating"):
        candidates = build_candidates(hist[i:i+1], time_w, raw, target_start[i:i+1], sensor_ids[i:i+1], profile=profile, train_end=train_end)[0]
        pso_pred = fuse_candidates(candidates.reshape(1, len(CANDIDATE_NAMES), PRED_LEN), cand_w)[0]

        prompt = build_llm_prompt(sensor_ids[i], hist[i], pso_pred, candidates, time_w, cand_w)
        if i < 20:
            prompt_f.write(json.dumps({
                "sample_id": int(sample_ids[i]),
                "sensor_id": int(sensor_ids[i]),
                "prompt": prompt
            }, ensure_ascii=False) + "\n")

        raw_text = ""
        used_fusion = False
        used_fallback = False
        try:
            raw_text = llama_generate(tokenizer, model, prompt)
            llm_pred = parse_pred(raw_text)
            if llm_pred is None:
                llm_pred = pso_pred.copy()
                used_fallback = True
        except Exception as e:
            raw_text = f"ERROR: {repr(e)}"
            llm_pred = pso_pred.copy()
            used_fallback = True

        llm_pred = np.maximum(llm_pred.astype(np.float32), 0.0)
        diff_ratio = np.mean(np.abs(llm_pred - pso_pred)) / (np.mean(pso_pred) + 1e-6)

        if diff_ratio < 0.08:
            final_pred = 0.90 * pso_pred + 0.10 * llm_pred
            used_fusion = True
        else:
            final_pred = pso_pred.copy()
            used_fallback = True

        local_max = max(float(np.max(hist[i])), float(np.max(pso_pred)), 1.0)
        final_pred = np.clip(final_pred, 0.0, local_max * 2.0 + 80.0)

        y_true_all.append(target[i])
        y_pso_all.append(pso_pred)
        y_llm_all.append(llm_pred)
        y_final_all.append(final_pred)
        fusion_count += int(used_fusion)
        fallback_count += int(used_fallback)

        rows.append({
            "sample_id": int(sample_ids[i]),
            "sensor_id": int(sensor_ids[i]),
            "target": json.dumps([round(float(x), 4) for x in target[i].tolist()], ensure_ascii=False),
            "pso_prediction": json.dumps([round(float(x), 4) for x in pso_pred.tolist()], ensure_ascii=False),
            "llm_prediction": json.dumps([round(float(x), 4) for x in llm_pred.tolist()], ensure_ascii=False),
            "final_prediction": json.dumps([round(float(x), 4) for x in final_pred.tolist()], ensure_ascii=False),
            "diff_ratio": float(diff_ratio),
            "used_fusion": int(used_fusion),
            "used_fallback": int(used_fallback),
            "raw_llm_output": raw_text[:1000],
        })

    prompt_f.close()

    y_true_all = np.asarray(y_true_all, dtype=np.float32)
    y_pso_all = np.asarray(y_pso_all, dtype=np.float32)
    y_llm_all = np.asarray(y_llm_all, dtype=np.float32)
    y_final_all = np.asarray(y_final_all, dtype=np.float32)

    result = {
        "num_llm_samples": int(len(sample_ids)),
        "pso_metrics": compute_metrics(y_true_all, y_pso_all, mask_threshold=5.0),
        "llm_raw_metrics": compute_metrics(y_true_all, y_llm_all, mask_threshold=5.0),
        "final_metrics": compute_metrics(y_true_all, y_final_all, mask_threshold=5.0),
        "fusion_count": int(fusion_count),
        "fallback_count": int(fallback_count),
        "fusion_rate": float(fusion_count / max(len(sample_ids), 1)),
        "fallback_rate": float(fallback_count / max(len(sample_ids), 1)),
    }

    pd.DataFrame(rows).to_csv(out_dir / "llm_test_predictions.csv", index=False, encoding="utf-8-sig")
    with open(out_dir / "llm_test_metrics.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print("\n[LLM Metrics]")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result






# -------------------------
# v6：MLP非线性残差校正模块
# -------------------------

def load_particle_from_json(path: Path):
    """
    读取已有 PSO 权重，避免重复训练。
    支持 pso_weights.json 中的 best_particle 字段。
    """
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if "best_particle" in obj:
            return np.array(obj["best_particle"], dtype=np.float64)
        if "time_weights" in obj and "candidate_weights" in obj:
            time_w = np.array(obj["time_weights"], dtype=np.float64)
            cand_dict = obj["candidate_weights"]
            cand_w = np.array([cand_dict.get(name, 1e-6) for name in CANDIDATE_NAMES], dtype=np.float64)
            return np.concatenate([time_w, cand_w], axis=0)
    except Exception as e:
        print(f"[WARN] 读取已有PSO权重失败: {path}, {repr(e)}")
    return None


def make_residual_features(hist, pso_pred, candidates, target_start_0based, sensor_ids):
    """
    构造残差校正特征，不使用Y，不造成标签泄露。
    """
    hist = np.asarray(hist, dtype=np.float32)
    pso_pred = np.asarray(pso_pred, dtype=np.float32)
    candidates = np.asarray(candidates, dtype=np.float32)

    n = hist.shape[0]
    diff = np.diff(hist, prepend=hist[:, :1], axis=1).astype(np.float32)

    stats = np.stack([
        hist[:, -1],
        hist.mean(axis=1),
        hist.std(axis=1),
        hist.max(axis=1),
        hist.min(axis=1),
        diff[:, -3:].mean(axis=1),
        pso_pred[:, 0],
        pso_pred[:, -1],
        pso_pred.mean(axis=1),
        pso_pred.std(axis=1),
    ], axis=1).astype(np.float32)

    tod = (target_start_0based % DAY_STEPS).astype(np.float32) / DAY_STEPS
    time_feat = np.stack([
        np.sin(2 * np.pi * tod),
        np.cos(2 * np.pi * tod),
    ], axis=1).astype(np.float32)

    sensor_feat = (sensor_ids.astype(np.float32).reshape(-1, 1) / max(N_SENSOR - 1, 1)).astype(np.float32)

    feat = np.concatenate([
        hist,
        diff,
        pso_pred,
        candidates.reshape(n, -1),
        stats,
        time_feat,
        sensor_feat,
    ], axis=1).astype(np.float32)

    return feat


def build_feature_target_batches(
    X, Y, index_df, raw, profile, train_end, particle,
    max_pairs=50000, seed=42, batch_size=2000, need_target=True
):
    sample_ids, sensor_ids, target_start = sample_pairs(
        X, Y, index_df, max_pairs=max_pairs, seed=seed
    )

    time_w, cand_w = decode_particle(particle)

    feats, targets, pso_preds, hists = [], [], [], []
    n = len(sample_ids)

    for st in tqdm(range(0, n, batch_size), desc="Building residual features", leave=False):
        ed = min(st + batch_size, n)
        sid = sample_ids[st:ed]
        sen = sensor_ids[st:ed]
        ts = target_start[st:ed]

        hist, target = gather_xy(X, Y, sid, sen)
        candidates = build_candidates(
            hist, time_w, raw, ts, sen,
            profile=profile,
            train_end=train_end
        )
        pso_pred = fuse_candidates(candidates, cand_w)
        feat = make_residual_features(hist, pso_pred, candidates, ts, sen)

        feats.append(feat)
        pso_preds.append(pso_pred.astype(np.float32))
        hists.append(hist.astype(np.float32))
        if need_target:
            targets.append(target.astype(np.float32))

    F = np.concatenate(feats, axis=0).astype(np.float32)
    P = np.concatenate(pso_preds, axis=0).astype(np.float32)
    H = np.concatenate(hists, axis=0).astype(np.float32)
    T = np.concatenate(targets, axis=0).astype(np.float32) if need_target else None

    meta = {
        "sample_ids": sample_ids,
        "sensor_ids": sensor_ids,
        "target_start": target_start,
    }
    return F, T, P, H, meta


def clip_final_prediction(final_pred, hist, pso_pred):
    final_pred = np.asarray(final_pred, dtype=np.float32)
    hist = np.asarray(hist, dtype=np.float32)
    pso_pred = np.asarray(pso_pred, dtype=np.float32)

    local_max = np.maximum(
        np.maximum(np.max(hist, axis=1, keepdims=True), np.max(pso_pred, axis=1, keepdims=True)),
        1.0
    )
    upper = local_max * 2.0 + 100.0
    return np.clip(final_pred, 0.0, upper).astype(np.float32)


def tune_residual_scale(target, pso_pred, residual_pred, hist, scales=None):
    if scales is None:
        scales = np.linspace(0.0, 1.5, 16)

    records = []
    best_scale = 0.0
    best_mae = float("inf")

    for s in scales:
        final_pred = pso_pred + float(s) * residual_pred
        final_pred = clip_final_prediction(final_pred, hist, pso_pred)
        m = compute_metrics(target, final_pred, mask_threshold=5.0)
        records.append({"scale": float(s), **m})
        if m["MAE"] < best_mae:
            best_mae = m["MAE"]
            best_scale = float(s)

    return best_scale, records


# -------------------------
# MLP residual network
# -------------------------

class MLPResidualDataset:
    def __init__(self, features, target, pso_pred, x_mean=None, x_std=None, y_scale=None):
        import torch

        self.features = np.asarray(features, dtype=np.float32)
        self.target = np.asarray(target, dtype=np.float32)
        self.pso_pred = np.asarray(pso_pred, dtype=np.float32)
        self.residual = self.target - self.pso_pred

        if x_mean is None:
            x_mean = self.features.mean(axis=0, keepdims=True).astype(np.float32)
        if x_std is None:
            x_std = self.features.std(axis=0, keepdims=True).astype(np.float32)
            x_std = np.maximum(x_std, 1e-6)

        if y_scale is None:
            # 残差尺度，用于训练稳定。按整体残差标准差估计。
            y_scale = float(np.std(self.residual) + 1e-6)
            y_scale = max(y_scale, 1.0)

        self.x_mean = x_mean.astype(np.float32)
        self.x_std = x_std.astype(np.float32)
        self.y_scale = float(y_scale)

        self.X = ((self.features - self.x_mean) / self.x_std).astype(np.float32)
        self.R = (self.residual / self.y_scale).astype(np.float32)

    def __len__(self):
        return self.X.shape[0]

    def __getitem__(self, idx):
        import torch
        return (
            torch.tensor(self.X[idx], dtype=torch.float32),
            torch.tensor(self.R[idx], dtype=torch.float32),
        )


class MLPResidualNet(nn.Module):
    def __init__(self, input_dim, hidden=512, dropout=0.15):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden),
            nn.BatchNorm1d(hidden),
            nn.ReLU(),
            nn.Dropout(dropout),

            nn.Linear(hidden, hidden // 2),
            nn.BatchNorm1d(hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),

            nn.Linear(hidden // 2, hidden // 4),
            nn.ReLU(),
            nn.Dropout(dropout),

            nn.Linear(hidden // 4, PRED_LEN),
        )

    def forward(self, x):
        return self.net(x)


def mlp_loss(pred_residual_norm, target_residual_norm):
    mae = torch.mean(torch.abs(pred_residual_norm - target_residual_norm))
    smooth = nn.functional.smooth_l1_loss(pred_residual_norm, target_residual_norm, beta=0.5)
    peak_mae = torch.mean(torch.abs(torch.max(pred_residual_norm, dim=1).values - torch.max(target_residual_norm, dim=1).values))
    return mae + 0.5 * smooth + 0.1 * peak_mae


@torch.no_grad()
def predict_mlp_residual(model, features, x_mean, x_std, y_scale, device, batch_size=4096):
    import torch
    model.eval()
    X = ((features.astype(np.float32) - x_mean) / x_std).astype(np.float32)
    outs = []
    for st in range(0, X.shape[0], batch_size):
        ed = min(st + batch_size, X.shape[0])
        xb = torch.tensor(X[st:ed], dtype=torch.float32, device=device)
        pred = model(xb).detach().cpu().numpy().astype(np.float32) * float(y_scale)
        outs.append(pred)
    return np.concatenate(outs, axis=0).astype(np.float32)


def train_mlp_residual(
    F_train, T_train, P_train,
    F_val, T_val, P_val, H_val,
    out_dir: Path,
    hidden=512,
    dropout=0.15,
    lr=1e-3,
    weight_decay=1e-4,
    batch_size=1024,
    epochs=80,
    patience=12,
    seed=42
):
    import torch
    from torch.utils.data import DataLoader

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[MLP device] {device}")
    if torch.cuda.is_available():
        print(f"[GPU] {torch.cuda.get_device_name(0)}")

    train_ds = MLPResidualDataset(F_train, T_train, P_train)
    val_ds = MLPResidualDataset(
        F_val, T_val, P_val,
        x_mean=train_ds.x_mean,
        x_std=train_ds.x_std,
        y_scale=train_ds.y_scale
    )

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False)

    model = MLPResidualNet(input_dim=F_train.shape[1], hidden=hidden, dropout=dropout).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=4)

    best_val_mae = float("inf")
    best_state = None
    best_epoch = -1
    bad = 0
    history = []

    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum = 0.0
        n_batches = 0

        pbar = tqdm(train_loader, desc=f"MLP Epoch {epoch}/{epochs}")
        for xb, rb in pbar:
            xb = xb.to(device)
            rb = rb.to(device)

            opt.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = mlp_loss(pred, rb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt.step()

            loss_sum += float(loss.detach().cpu())
            n_batches += 1
            pbar.set_postfix({"loss": f"{loss_sum / max(n_batches, 1):.4f}"})

        # 验证：先直接预测残差，再找最佳scale
        R_val_pred = predict_mlp_residual(
            model, F_val, train_ds.x_mean, train_ds.x_std, train_ds.y_scale,
            device=device, batch_size=4096
        )
        scale, scale_records = tune_residual_scale(T_val, P_val, R_val_pred, H_val)
        best_scale_mae = min(r["MAE"] for r in scale_records)
        scheduler.step(best_scale_mae)

        item = {
            "epoch": int(epoch),
            "train_loss": float(loss_sum / max(n_batches, 1)),
            "val_best_scale": float(scale),
            "val_MAE": float(best_scale_mae),
            "lr": float(opt.param_groups[0]["lr"]),
        }
        history.append(item)

        print(f"[MLP Epoch {epoch}] val_MAE={best_scale_mae:.4f}, best_scale={scale:.2f}, lr={opt.param_groups[0]['lr']:.2e}")

        with open(out_dir / "mlp_train_history.json", "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

        if best_scale_mae < best_val_mae:
            best_val_mae = best_scale_mae
            best_epoch = epoch
            bad = 0
            best_state = {
                "model_state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                "x_mean": train_ds.x_mean,
                "x_std": train_ds.x_std,
                "y_scale": float(train_ds.y_scale),
                "best_val_mae": float(best_val_mae),
                "best_epoch": int(best_epoch),
                "hidden": int(hidden),
                "dropout": float(dropout),
                "input_dim": int(F_train.shape[1]),
                "best_scale": float(scale),
            }
            torch.save(best_state, out_dir / "mlp_residual_best.pth")
            with open(out_dir / "mlp_val_scale_search_best.json", "w", encoding="utf-8") as f:
                json.dump(scale_records, f, ensure_ascii=False, indent=2)
            print(f"[SAVE] mlp_residual_best.pth, val_MAE={best_val_mae:.4f}")
        else:
            bad += 1

        if bad >= patience:
            print(f"[EarlyStop] {patience} epochs no improvement.")
            break

    # 加载最佳
    ckpt = torch.load(out_dir / "mlp_residual_best.pth", map_location=device, weights_only=False)
    model = MLPResidualNet(input_dim=ckpt["input_dim"], hidden=ckpt["hidden"], dropout=ckpt["dropout"]).to(device)
    model.load_state_dict(ckpt["model_state_dict"])
    model.eval()

    return {
        "model": model,
        "x_mean": ckpt["x_mean"],
        "x_std": ckpt["x_std"],
        "y_scale": float(ckpt["y_scale"]),
        "best_scale": float(ckpt["best_scale"]),
        "best_val_mae": float(ckpt["best_val_mae"]),
        "best_epoch": int(ckpt["best_epoch"]),
        "device": device,
    }


def evaluate_mlp_residual_model(
    X, Y, index_df, raw, profile, train_end, particle, mlp_pack,
    max_pairs=50000, seed=123, batch_size=2000, save_pred_path=None
):
    F, T, P, H, meta = build_feature_target_batches(
        X, Y, index_df, raw, profile, train_end, particle,
        max_pairs=max_pairs,
        seed=seed,
        batch_size=batch_size,
        need_target=True
    )

    R_pred = predict_mlp_residual(
        mlp_pack["model"], F, mlp_pack["x_mean"], mlp_pack["x_std"], mlp_pack["y_scale"],
        device=mlp_pack["device"], batch_size=4096
    )
    final_pred = P + float(mlp_pack["best_scale"]) * R_pred
    final_pred = clip_final_prediction(final_pred, H, P)

    pso_metrics = compute_metrics(T, P, mask_threshold=5.0)
    final_metrics = compute_metrics(T, final_pred, mask_threshold=5.0)

    if save_pred_path is not None:
        rows = []
        n = min(len(T), 5000)
        for i in range(n):
            rows.append({
                "sample_id": int(meta["sample_ids"][i]),
                "sensor_id": int(meta["sensor_ids"][i]),
                "target_start_0based": int(meta["target_start"][i]),
                "target": json.dumps([round(float(x), 4) for x in T[i].tolist()], ensure_ascii=False),
                "pso_prediction": json.dumps([round(float(x), 4) for x in P[i].tolist()], ensure_ascii=False),
                "mlp_residual_prediction": json.dumps([round(float(x), 4) for x in R_pred[i].tolist()], ensure_ascii=False),
                "final_prediction": json.dumps([round(float(x), 4) for x in final_pred[i].tolist()], ensure_ascii=False),
                "pso_mae": float(np.mean(np.abs(P[i] - T[i]))),
                "final_mae": float(np.mean(np.abs(final_pred[i] - T[i]))),
            })
        pd.DataFrame(rows).to_csv(save_pred_path, index=False, encoding="utf-8-sig")

    return {
        "pso_metrics": pso_metrics,
        "mlp_residual_corrected_metrics": final_metrics,
        "mlp_residual_scale": float(mlp_pack["best_scale"]),
        "mlp_best_val_mae": float(mlp_pack["best_val_mae"]),
        "mlp_best_epoch": int(mlp_pack["best_epoch"]),
    }


def save_prediction_plot_from_csv(csv_path: Path, out_path: Path):
    try:
        import matplotlib.pyplot as plt
        df = pd.read_csv(csv_path)
        if len(df) == 0:
            return
        row = df.iloc[0]
        target = np.array(json.loads(row["target"]), dtype=float)
        pso = np.array(json.loads(row["pso_prediction"]), dtype=float)
        final = np.array(json.loads(row["final_prediction"]), dtype=float)

        x = np.arange(1, PRED_LEN + 1)
        plt.figure()
        plt.plot(x, target, marker="o", label="True")
        plt.plot(x, pso, marker="o", label="PSO")
        plt.plot(x, final, marker="o", label="PSO+MLP Residual")
        plt.xlabel("Future step")
        plt.ylabel("Traffic flow")
        plt.title("Prediction Example")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_path, dpi=200)
        plt.close()
    except Exception as e:
        print(f"[WARN] 保存预测示例图失败: {repr(e)}")



def train_mlp_residual_final(
    F_fit, T_fit, P_fit,
    out_dir: Path,
    fixed_scale=0.8,
    hidden=768,
    dropout=0.10,
    lr=8e-4,
    weight_decay=1e-4,
    batch_size=1024,
    epochs=70,
    seed=42
):
    """
    最终交付模式：
    前一轮已用验证集确定 MLP 结构和 residual_scale。
    本轮将 train+val 合并训练最终 MLP 残差模型，测试集仍然完全不参与训练。
    """
    import torch
    from torch.utils.data import DataLoader

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[Final MLP device] {device}")
    if torch.cuda.is_available():
        print(f"[GPU] {torch.cuda.get_device_name(0)}")

    fit_ds = MLPResidualDataset(F_fit, T_fit, P_fit)
    loader = DataLoader(fit_ds, batch_size=batch_size, shuffle=True, num_workers=0, drop_last=False)

    model = MLPResidualNet(input_dim=F_fit.shape[1], hidden=hidden, dropout=dropout).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(epochs, 1), eta_min=lr * 0.05)

    history = []
    for epoch in range(1, epochs + 1):
        model.train()
        loss_sum = 0.0
        n_batches = 0

        pbar = tqdm(loader, desc=f"Final MLP Epoch {epoch}/{epochs}")
        for xb, rb in pbar:
            xb = xb.to(device)
            rb = rb.to(device)

            opt.zero_grad(set_to_none=True)
            pred = model(xb)
            loss = mlp_loss(pred, rb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt.step()

            loss_sum += float(loss.detach().cpu())
            n_batches += 1
            pbar.set_postfix({"loss": f"{loss_sum / max(n_batches, 1):.4f}"})

        scheduler.step()
        item = {
            "epoch": int(epoch),
            "train_loss": float(loss_sum / max(n_batches, 1)),
            "lr": float(opt.param_groups[0]["lr"]),
            "fixed_residual_scale": float(fixed_scale),
        }
        history.append(item)

        with open(out_dir / "final_mlp_train_history.json", "w", encoding="utf-8") as f:
            json.dump(history, f, ensure_ascii=False, indent=2)

        print(
            f"[Final MLP Epoch {epoch}] "
            f"loss={item['train_loss']:.4f}, "
            f"lr={item['lr']:.2e}, "
            f"fixed_scale={fixed_scale}"
        )

    pack = {
        "model": model,
        "x_mean": fit_ds.x_mean,
        "x_std": fit_ds.x_std,
        "y_scale": float(fit_ds.y_scale),
        "best_scale": float(fixed_scale),
        "best_val_mae": -1.0,
        "best_epoch": int(epochs),
        "device": device,
    }

    torch.save({
        "model_state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
        "x_mean": fit_ds.x_mean,
        "x_std": fit_ds.x_std,
        "y_scale": float(fit_ds.y_scale),
        "fixed_scale": float(fixed_scale),
        "hidden": int(hidden),
        "dropout": float(dropout),
        "input_dim": int(F_fit.shape[1]),
        "epochs": int(epochs),
    }, out_dir / "final_mlp_residual_trainval.pth")

    return pack


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", type=str, default="./pems03_xy_12to12")
    parser.add_argument("--raw_csv", type=str, default="./PEMS-03.csv")
    parser.add_argument("--model_path", type=str, default="./models/Meta-Llama-3-8B-Instruct")
    parser.add_argument("--out_dir", type=str, default="./outputs_pso_llm_xy_12to12_v7_final_trainval")

    parser.add_argument("--max_pso_samples", type=int, default=5000)
    parser.add_argument("--max_eval_pairs", type=int, default=100000)
    parser.add_argument("--max_residual_train_pairs", type=int, default=200000)
    parser.add_argument("--max_residual_val_pairs", type=int, default=80000)

    parser.add_argument("--pso_particles", type=int, default=30)
    parser.add_argument("--pso_iters", type=int, default=30)
    parser.add_argument("--feature_batch_size", type=int, default=2000)

    parser.add_argument("--mlp_hidden", type=int, default=768)
    parser.add_argument("--mlp_dropout", type=float, default=0.10)
    parser.add_argument("--mlp_lr", type=float, default=8e-4)
    parser.add_argument("--mlp_weight_decay", type=float, default=1e-4)
    parser.add_argument("--mlp_batch_size", type=int, default=1024)

    # v7 特有参数
    parser.add_argument("--final_epochs", type=int, default=70)
    parser.add_argument("--residual_scale", type=float, default=0.8)

    parser.add_argument("--reuse_pso", type=int, default=1)
    parser.add_argument("--pso_weights_input", type=str, default="./outputs_pso_llm_xy_12to12_v5_residual/pso_weights.json")
    parser.add_argument("--run_llm", type=int, default=0)
    parser.add_argument("--max_llm_samples", type=int, default=50)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    out_dir = Path(args.out_dir)
    ensure_dir(out_dir)

    data_dir = Path(args.data_dir)
    print("[1/7] 读取客户要求的 X/Y 数据集")
    X_train = load_npy(data_dir / "X_train.npy")
    Y_train = load_npy(data_dir / "Y_train.npy")
    X_val = load_npy(data_dir / "X_val.npy")
    Y_val = load_npy(data_dir / "Y_val.npy")
    X_test = load_npy(data_dir / "X_test.npy")
    Y_test = load_npy(data_dir / "Y_test.npy")

    train_index = load_index(data_dir / "train_index.csv")
    val_index = load_index(data_dir / "val_index.csv")
    test_index = load_index(data_dir / "test_index.csv")

    print(f"X_train={X_train.shape}, Y_train={Y_train.shape}")
    print(f"X_val={X_val.shape}, Y_val={Y_val.shape}")
    print(f"X_test={X_test.shape}, Y_test={Y_test.shape}")

    print("[2/7] 读取原始CSV并构建训练集profile")
    raw = load_raw_csv(Path(args.raw_csv))
    train_end = infer_train_end_from_index(train_index)
    profile = build_time_of_day_profile(raw, train_end)

    print("[3/7] 获取或训练 PSO 权重")
    best_particle = None
    if args.reuse_pso:
        best_particle = load_particle_from_json(Path(args.pso_weights_input))
        if best_particle is not None:
            print(f"[Reuse PSO] 已读取: {args.pso_weights_input}")

    if best_particle is None:
        print("[Train PSO] 未读取到可用PSO权重，开始训练PSO。")
        train_sample_ids, train_sensor_ids, train_target_start = sample_pairs(
            X_train, Y_train, train_index, max_pairs=args.max_pso_samples, seed=args.seed
        )
        train_hist, train_target = gather_xy(X_train, Y_train, train_sample_ids, train_sensor_ids)
        t0 = time.time()
        best_particle, history = train_pso(
            train_hist, train_target, train_target_start, train_sensor_ids,
            raw, profile=profile, train_end=train_end,
            particles=args.pso_particles,
            iters=args.pso_iters,
            seed=args.seed
        )
        print(f"[PSO Done] {time.time() - t0:.1f}s")
    else:
        history = []

    time_w, cand_w = decode_particle(best_particle)
    pso_info = {
        "task": "PeMS03 12->12 PSO baseline for final train+val MLP residual correction",
        "candidate_names": CANDIDATE_NAMES,
        "time_weights": [float(x) for x in time_w],
        "candidate_weights": {name: float(w) for name, w in zip(CANDIDATE_NAMES, cand_w)},
        "history": history,
        "best_particle": [float(x) for x in best_particle],
        "source": args.pso_weights_input if args.reuse_pso else "trained_in_v7",
    }
    with open(out_dir / "pso_weights.json", "w", encoding="utf-8") as f:
        json.dump(pso_info, f, ensure_ascii=False, indent=2)
    if history:
        save_curve(history, out_dir)

    print("[4/7] 构建 train+val 残差训练特征")
    F_train, T_train, P_train, H_train, _ = build_feature_target_batches(
        X_train, Y_train, train_index, raw, profile, train_end, best_particle,
        max_pairs=args.max_residual_train_pairs,
        seed=args.seed + 10,
        batch_size=args.feature_batch_size,
        need_target=True
    )
    F_val, T_val, P_val, H_val, _ = build_feature_target_batches(
        X_val, Y_val, val_index, raw, profile, train_end, best_particle,
        max_pairs=args.max_residual_val_pairs,
        seed=args.seed + 11,
        batch_size=args.feature_batch_size,
        need_target=True
    )

    F_fit = np.concatenate([F_train, F_val], axis=0).astype(np.float32)
    T_fit = np.concatenate([T_train, T_val], axis=0).astype(np.float32)
    P_fit = np.concatenate([P_train, P_val], axis=0).astype(np.float32)

    print(f"Final residual fit features: {F_fit.shape}, target: {T_fit.shape}")
    print(f"Using fixed residual_scale={args.residual_scale}")

    print("[5/7] 使用 train+val 训练最终 MLP 残差模型")
    mlp_pack = train_mlp_residual_final(
        F_fit, T_fit, P_fit,
        out_dir=out_dir,
        fixed_scale=args.residual_scale,
        hidden=args.mlp_hidden,
        dropout=args.mlp_dropout,
        lr=args.mlp_lr,
        weight_decay=args.mlp_weight_decay,
        batch_size=args.mlp_batch_size,
        epochs=args.final_epochs,
        seed=args.seed
    )

    print("[6/7] 测试集评估 PSO 与 PSO+Final MLP Residual")
    test_result = evaluate_mlp_residual_model(
        X_test, Y_test, test_index, raw, profile, train_end,
        best_particle, mlp_pack,
        max_pairs=args.max_eval_pairs,
        seed=args.seed + 12,
        batch_size=args.feature_batch_size,
        save_pred_path=out_dir / "test_predictions.csv"
    )

    final_result = {
        "task": "PeMS03 12->12 traffic flow forecasting",
        "data_logic": "第1个样本 X=1-12, Y=13-24；第2个样本 X=2-13, Y=14-25；每列为一个观测点，共358列。",
        "method": "PSO+LLM 主框架 + Final train+val MLP nonlinear residual correction",
        "note": "上一轮已用验证集确定MLP结构和残差融合强度；本轮将train+val合并训练最终残差模型，测试集完全不参与训练。",
        "pso_test_metrics": test_result["pso_metrics"],
        "final_mlp_residual_corrected_test_metrics": test_result["mlp_residual_corrected_metrics"],
        "residual_scale": float(args.residual_scale),
        "candidate_names": CANDIDATE_NAMES,
        "time_weights": [float(x) for x in time_w],
        "candidate_weights": {name: float(w) for name, w in zip(CANDIDATE_NAMES, cand_w)},
        "config": vars(args),
    }

    with open(out_dir / "final_test_metrics.json", "w", encoding="utf-8") as f:
        json.dump(final_result, f, ensure_ascii=False, indent=2)

    save_prediction_plot_from_csv(out_dir / "test_predictions.csv", out_dir / "prediction_examples.png")

    print("[Final Test Metrics]")
    print(json.dumps(final_result, ensure_ascii=False, indent=2))

    if args.run_llm:
        print("[7/7] 可选：运行 LLM 提示词预测。注意：LLM不替代最终残差模型。")
        evaluate_llm(
            X_test, Y_test, test_index, raw, profile, train_end,
            best_particle, out_dir,
            model_path=args.model_path,
            max_llm_samples=args.max_llm_samples,
            seed=args.seed + 20
        )
    else:
        print("[7/7] 跳过 LLM 推理。")

    print("[Done]")
    print(f"输出目录: {out_dir}")
    for name in [
        "pso_weights.json",
        "final_mlp_residual_trainval.pth",
        "final_mlp_train_history.json",
        "final_test_metrics.json",
        "test_predictions.csv",
        "prediction_examples.png",
        "llm_test_metrics.json",
    ]:
        p = out_dir / name
        if p.exists():
            print(f"  {p}")


if __name__ == "__main__":
    main()
