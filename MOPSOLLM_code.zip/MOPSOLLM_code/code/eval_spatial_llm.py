#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""评估已经训练好的空间增强 LoRA Adapter。"""
import argparse
from spatial_llm_pipeline import cmd_eval


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model_path', required=True)
    p.add_argument('--lora_adapter', required=True)
    p.add_argument('--val_file', required=True)
    p.add_argument('--out_dir', required=True)
    p.add_argument('--max_eval_samples', type=int, default=5000)
    p.add_argument('--max_new_tokens', type=int, default=160)
    p.add_argument('--bf16', type=int, default=1)
    p.add_argument('--local_files_only', type=int, default=1)
    p.add_argument('--fallback_on_parse_fail', type=int, default=1)
    args = p.parse_args()
    cmd_eval(args)


if __name__ == '__main__':
    main()
