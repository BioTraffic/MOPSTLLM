#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
spatial_llm_pipeline.py

严格按 Markdown 逻辑：
PSO候选预测 -> Top-K空间相关节点 -> 空间前置修正 -> 空间增强Prompt -> Llama LoRA -> LLM predicted_flow作为最终结果。
采用空间前置修正，不依赖额外时序卷积模块。

用法：
1) 生成空间增强messages数据：
python spatial_llm_pipeline.py generate --data_dir ./pems03_xy_12to12 --raw_csv ./PEMS-03.csv --pso_weights ./outputs_pso_llm_xy_12to12_v11_full/pso_weights.json --out_dir ./spatial_llm_data --beta auto --max_train_samples 100000 --max_val_samples 20000

2) 训练LoRA并评估：
python spatial_llm_pipeline.py train --model_path ./models/Meta-Llama-3-8B-Instruct --train_file ./spatial_llm_data/train_messages.jsonl --val_file ./spatial_llm_data/val_messages.jsonl --out_dir ./spatial_llm_lora --max_train_records 50000 --max_generate_samples 200

3) 单独评估已训练adapter：
python spatial_llm_pipeline.py eval --model_path ./models/Meta-Llama-3-8B-Instruct --lora_adapter ./spatial_llm_lora/lora_adapter --val_file ./spatial_llm_data/val_messages.jsonl --out_dir ./spatial_llm_eval
"""
from __future__ import annotations

import argparse, csv, json, math, os, random, re, time
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# 使用原项目的 PSO 候选实现，避免改变已优化权重对应的模型。
import pso_prediction_core as pso_core

CANDIDATES = [
    "last_repeat", "weighted_linear", "weighted_mean", "recent_delta",
    "previous_day", "previous_day_delta", "previous_day_ratio",
    "previous_week", "previous_week_delta", "day_week_blend",
    "profile_mean", "profile_median", "profile_ratio",
    "analog_same_tod", "analog_profile_blend",
]


def seed_all(seed: int):
    random.seed(seed); np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    except Exception:
        pass


def rlist(x, nd=3):
    a = np.asarray(x, dtype=np.float32).reshape(-1)
    return [round(float(v), nd) for v in a]


def nonneg(x):
    return np.maximum(np.asarray(x, dtype=np.float32), 0.0)


def norm_w(w):
    w = np.nan_to_num(np.asarray(w, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0)
    w = np.maximum(w, 0.0)
    s = float(w.sum())
    return w / s if s > 1e-12 else np.ones_like(w) / max(1, len(w))


def find_key(obj, key):
    if isinstance(obj, dict):
        if key in obj: return obj[key]
        for v in obj.values():
            r = find_key(v, key)
            if r is not None: return r
    if isinstance(obj, list):
        for v in obj:
            r = find_key(v, key)
            if r is not None: return r
    return None


def load_pso(path: Path):
    data = json.loads(path.read_text(encoding="utf-8"))
    tw = find_key(data, "time_weights")
    if tw is None or len(np.asarray(tw).reshape(-1)) != 12:
        raise ValueError("PSO 权重缺少合法 time_weights（12维），禁止使用默认值冒充训练权重")
    time_w = norm_w(np.asarray(tw).reshape(-1)).astype(np.float32)

    cw = find_key(data, "candidate_weights")
    cn = find_key(data, "candidate_names")
    if isinstance(cw, dict):
        raw = {str(k): float(v) for k, v in cw.items()}
    elif isinstance(cw, list):
        if isinstance(cn, list) and len(cn) == len(cw): raw = {str(k): float(v) for k, v in zip(cn, cw)}
        elif len(cw) == len(CANDIDATES): raw = {k: float(v) for k, v in zip(CANDIDATES, cw)}
        else: raise ValueError("PSO candidate_weights 数量与候选名称不一致")
    else:
        raise ValueError("PSO 权重缺少合法 candidate_weights")
    if set(raw) != set(CANDIDATES):
        raise ValueError("PSO 候选名称与当前模型不一致，不能直接复用权重")
    vals = norm_w([raw[k] for k in CANDIDATES])
    cand_w = {k: float(v) for k, v in zip(CANDIDATES, vals)}
    print("[PSO] candidate weights:")
    for k, v in sorted(cand_w.items(), key=lambda kv: kv[1], reverse=True):
        print(f"  {k:24s} {v:.8f}")
    # 权重文件保留了 PSO 最优粒子时，优先核实权重解码关系。
    if "best_particle" in data:
        particle = np.asarray(data["best_particle"], dtype=np.float64)
        if particle.shape != (12 + len(CANDIDATES),):
            raise ValueError("PSO best_particle 维度错误")
        ref_t, ref_c = pso_core.decode_particle(particle)
        got_c = np.array([cand_w[k] for k in CANDIDATES])
        if not (np.allclose(time_w, ref_t, atol=1e-4) and np.allclose(got_c, ref_c, atol=1e-4)):
            raise ValueError("PSO 存档权重与 best_particle 解码值不一致")
    return time_w, cand_w


def load_arrays(data_dir: Path):
    arr = {}
    for name in ["X_train", "Y_train", "X_val", "Y_val"]:
        p = data_dir / f"{name}.npy"
        if not p.exists(): raise FileNotFoundError(p)
        arr[name] = np.load(p).astype(np.float32, copy=False)
        print(f"[LOAD] {name}: {arr[name].shape}")
    return arr


def build_profile(raw_train: np.ndarray, period=288):
    T, N = raw_train.shape
    mean = np.zeros((period, N), dtype=np.float32)
    med = np.zeros((period, N), dtype=np.float32)
    gm, gd = raw_train.mean(0), np.median(raw_train, axis=0)
    for t in range(period):
        v = raw_train[np.arange(t, T, period)]
        mean[t] = v.mean(0) if len(v) else gm
        med[t] = np.median(v, axis=0) if len(v) else gd
    return {"mean": mean, "median": med}


def raw_future(raw, start, node):
    if start < 0 or start + 12 > raw.shape[0]: return None
    return raw[start:start+12, node].astype(np.float32)


def wlinear(hist, time_w):
    x = np.arange(12, dtype=np.float32); y = hist.astype(np.float32); w = norm_w(time_w).astype(np.float32)
    xm, ym = float((x*w).sum()), float((y*w).sum())
    slope = float(((x-xm)*(y-ym)*w).sum()) / (float(((x-xm)**2*w).sum()) + 1e-8)
    return nonneg((ym - slope*xm) + slope*np.arange(12, 24, dtype=np.float32))


def make_candidates(hist, raw, raw_start, node, time_w, profile, period=288):
    hist = np.asarray(hist, dtype=np.float32).reshape(12)
    last = float(hist[-1]); fut = raw_start + 12
    pred = {}
    pred["last_repeat"] = np.full(12, last, dtype=np.float32)
    pred["weighted_mean"] = np.full(12, float((hist*time_w).sum()), dtype=np.float32)
    pred["weighted_linear"] = wlinear(hist, time_w)
    delta = float(np.mean(np.diff(hist[-4:]))) if len(hist) >= 4 else float(hist[-1]-hist[-2])
    pred["recent_delta"] = nonneg(last + delta*np.arange(1, 13, dtype=np.float32))

    pd = raw_future(raw, fut-period, node); pw = raw_future(raw, fut-7*period, node)
    if pd is None: pd = pred["weighted_mean"].copy()
    if pw is None: pw = pd.copy()
    pred["previous_day"] = nonneg(pd); pred["previous_week"] = nonneg(pw)
    pdh = raw_future(raw, raw_start-period, node); pwh = raw_future(raw, raw_start-7*period, node)
    if pdh is not None:
        pred["previous_day_delta"] = nonneg(pd + (last - float(pdh[-1])))
        pred["previous_day_ratio"] = nonneg(pd * (last / max(float(pdh[-1]), 1e-3)))
    else:
        pred["previous_day_delta"] = pred["previous_day"].copy(); pred["previous_day_ratio"] = pred["previous_day"].copy()
    pred["previous_week_delta"] = nonneg(pw + (last - float(pwh[-1]))) if pwh is not None else pred["previous_week"].copy()
    pred["day_week_blend"] = nonneg(0.5*pred["previous_day"] + 0.5*pred["previous_week"])

    tods = ((fut + np.arange(12)) % period).astype(np.int64)
    pm = profile["mean"][tods, node].astype(np.float32); pmed = profile["median"][tods, node].astype(np.float32)
    pred["profile_mean"] = nonneg(pm); pred["profile_median"] = nonneg(pmed)
    cur_tod = (raw_start + 11) % period
    ratio = last / max(float(profile["mean"][cur_tod, node]), 1e-3)
    pred["profile_ratio"] = nonneg(pm * ratio)
    vals = [raw_future(raw, fut-d*period, node) for d in range(1, 8)]
    vals = [v for v in vals if v is not None]
    if vals:
        an = np.mean(np.stack(vals), axis=0).astype(np.float32)
        an = an * (float(hist.mean()) / max(float(an.mean()), 1e-3))
        pred["analog_same_tod"] = nonneg(an)
    else:
        pred["analog_same_tod"] = pred["profile_ratio"].copy()
    pred["analog_profile_blend"] = nonneg(0.6*pred["analog_same_tod"] + 0.4*pred["profile_ratio"])
    return {k: nonneg(pred.get(k, pred["weighted_mean"])) for k in CANDIDATES}


def fuse(cands, cand_w):
    y = np.zeros(12, dtype=np.float32); s = 0.0
    for k in CANDIDATES:
        w = float(cand_w.get(k, 0.0)); y += w*cands[k]; s += w
    return nonneg(y / max(s, 1e-12))


def similarity(raw_train, method="pearson"):
    X = raw_train.astype(np.float32).T
    if method == "pearson": X = X - X.mean(1, keepdims=True)
    X = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-8)
    S = np.nan_to_num(X @ X.T).astype(np.float32)
    np.fill_diagonal(S, -np.inf)
    return S


def topk_from_sim(S, k):
    out = {}
    for i in range(S.shape[0]):
        idx = np.argsort(S[i])[::-1][:k]
        out[i] = [(int(j), float(S[i, j])) for j in idx]
    return out


def softmax(x, tau=0.1):
    z = np.asarray(x, dtype=np.float32) / max(tau, 1e-6); z -= np.max(z)
    e = np.exp(z); return e / (e.sum() + 1e-12)


def load_window_starts(data_dir: Path, arr: dict, raw: np.ndarray):
    """从原数据集的显式索引确定每个窗口的原始CSV行，杜绝train窗口数充当val偏移。"""
    starts = {}
    for split in ("train", "val"):
        path = data_dir / f"{split}_index.csv"
        if not path.is_file():
            raise FileNotFoundError(f"缺少 {path}；无法安全对齐CSV与{split}窗口。原PSO代码也使用该索引。")
        with path.open(newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        n = len(arr[f"X_{split}"])
        if len(rows) != n:
            raise ValueError(f"{path} 行数 {len(rows)} != X_{split} 窗口数 {n}")
        if not rows: raise ValueError(f"{path} 为空")
        keys = set(rows[0].keys())
        if "input_start_row_1based" in keys:
            out = np.asarray([int(r["input_start_row_1based"]) - 1 for r in rows], dtype=np.int64)
        elif "target_start_row_1based" in keys:
            out = np.asarray([int(r["target_start_row_1based"]) - 13 for r in rows], dtype=np.int64)
        elif "start" in keys:
            out = np.asarray([int(r["start"]) for r in rows], dtype=np.int64)
        else:
            raise ValueError(f"{path} 缺少可识别窗口列：input_start_row_1based / target_start_row_1based / start")
        if np.any(out < 0) or np.any(out + 24 > len(raw)):
            raise ValueError(f"{path} 窗口位置越界，检查行号从0还是从1开始")
        xx, yy = arr[f"X_{split}"], arr[f"Y_{split}"]
        check_idx = sorted(set(np.linspace(0, n-1, min(n, 32), dtype=int).tolist()))
        for idx in check_idx:
            j = int(out[idx]); hx, hy = raw[j:j+12], raw[j+12:j+24]
            if not np.allclose(hx, xx[idx], atol=1e-3, rtol=0, equal_nan=False):
                raise ValueError(f"{split} X窗口 {idx} 与raw[{j}:{j+12}]不符，禁止错位生成")
            if not np.allclose(hy, yy[idx], atol=1e-3, rtol=0, equal_nan=False):
                raise ValueError(f"{split} Y窗口 {idx} 与raw[{j+12}:{j+24}]不符，禁止错位生成")
        starts[split] = out
        print(f"[INDEX] {split}: {n} windows; first_raw={int(out[0])}, last_raw={int(out[-1])}")
    train_end = int(np.max(starts["train"]) + 24)
    val_start = int(np.min(starts["val"]))
    if val_start < train_end:
        raise ValueError(f"验证集原始起点{val_start}早于训练标签终点{train_end}，存在时间重叠；请确认实验切分")
    return starts, train_end


class Builder:
    def __init__(self, raw, arr, time_w, cand_w, profile, topk, beta, tau, starts, train_end):
        self.raw, self.arr, self.time_w, self.cand_w = raw, arr, time_w, cand_w
        self.profile, self.topk, self.beta, self.tau = profile, topk, float(beta), float(tau)
        self.starts, self.train_end = starts, train_end
        self.cw_array = np.array([cand_w[k] for k in CANDIDATES], dtype=np.float32)
    def XY(self, split): return self.arr[f"X_{split}"], self.arr[f"Y_{split}"]
    def raw_start(self, split, idx): return int(self.starts[split][int(idx)])
    @lru_cache(maxsize=8192)
    def node_pso(self, split, idx, node):
        X, _ = self.XY(split)
        hist = X[int(idx), :, int(node)].reshape(1, 12)
        target_start = np.array([self.raw_start(split, idx) + 12], dtype=np.int64)
        sensors = np.array([int(node)], dtype=np.int64)
        # 不要使用独立重写的make_candidates()。PSO权重仅与原pso_prediction_core一致。
        candidate_batch = pso_core.build_candidates(
            hist, self.time_w, self.raw, target_start, sensors,
            profile=self.profile, train_end=self.train_end,
        )
        prediction = pso_core.fuse_candidates(candidate_batch, self.cw_array)[0]
        c = {name: candidate_batch[0, k] for k, name in enumerate(CANDIDATES)}
        return c, prediction
    def item(self, split, idx, node, nd=3):
        X, Y = self.XY(split); hist = X[idx, :, node]; y = Y[idx, :, node]
        c, p = self.node_pso(split, idx, node)
        neigh = self.topk[int(node)]; sims = [s for _, s in neigh]; aw = softmax(sims, self.tau)
        ninfo, plist = [], []
        for (j, s), w in zip(neigh, aw):
            _, pj = self.node_pso(split, idx, j); plist.append(pj)
            ninfo.append({"sensor_id": int(j), "similarity": round(float(s), nd), "weight": round(float(w), nd), "history_12": rlist(X[idx, :, j], nd), "pso_prediction_12": rlist(pj, nd)})
        S = np.sum(np.stack(plist)*aw[:, None], axis=0).astype(np.float32) if plist else p.copy()
        ps = nonneg((1-self.beta)*p + self.beta*S)
        return {"split": split, "sample_idx": int(idx), "sensor_id": int(node), "history_12": hist, "y_true": y, "candidates": c, "pso_prediction": p, "neighbors": ninfo, "spatial_aggregation": S, "spatial_prediction": ps}


def trend(hist):
    h = np.asarray(hist); d = float(h[-1]-h[0]); peak = int(np.argmax(h))+1; valley = int(np.argmin(h))+1
    t = "整体上升" if d > 5 else ("整体下降" if d < -5 else "整体相对平稳")
    return f"{t}，峰值在历史第{peak}个时间步，低谷在历史第{valley}个时间步。"


def make_record(it, nd=3, compact=True):
    sensor = it["sensor_id"]
    system = (
        '你是交通流量预测器。仅输出一个JSON对象，字段严格为'
        '{"sensor_id":"sensor_N","predicted_flow":[12个非负有限数值]}。'
        'sensor_id必须等于用户输入的目标节点。禁止Markdown、解释和额外字段。'
    )
    if compact:
        # 保留目标节点以及最重要的 PSO、空间与邻居预测，避免几十条冗长候选淹没标签。
        user = {
            "目标节点": f"sensor_{sensor}",
            "历史12步流量": rlist(it["history_12"], nd),
            "目标节点PSO预测": rlist(it["pso_prediction"], nd),
            "TopK空间相关节点": [
                {"sensor_id": f"sensor_{x['sensor_id']}",
                 "weight": x["weight"],
                 "pso_prediction_12": x["pso_prediction_12"]}
                for x in it["neighbors"]
            ],
            "空间加权预测": rlist(it["spatial_aggregation"], nd),
            "空间增强预测": rlist(it["spatial_prediction"], nd),
            "目标输出步数": 12,
        }
    else:
        user = {
            "目标节点": f"sensor_{sensor}",
            "历史12步流量": rlist(it["history_12"], nd),
            "PSO候选预测结果": {k: rlist(it["candidates"][k], nd) for k in CANDIDATES},
            "目标节点PSO融合预测": rlist(it["pso_prediction"], nd),
            "TopK空间相关节点": it["neighbors"],
            "空间聚合预测": rlist(it["spatial_aggregation"], nd),
            "空间增强预测": rlist(it["spatial_prediction"], nd),
            "趋势描述": trend(it["history_12"]),
            "输出要求": "只输出JSON；predicted_flow长度为12；非负、有限；不输出解释。",
        }
    ans = {"sensor_id": f"sensor_{sensor}", "predicted_flow": rlist(it["y_true"], nd)}
    return {
        "messages": [{"role":"system","content":system},
                     {"role":"user","content":json.dumps(user, ensure_ascii=False)},
                     {"role":"assistant","content":json.dumps(ans, ensure_ascii=False)}],
        "meta": {"split": it["split"], "sample_idx": it["sample_idx"], "sensor_id": sensor,
                 "y_true": ans["predicted_flow"],
                 "pso_prediction": rlist(it["pso_prediction"], nd),
                 "spatial_aggregation": rlist(it["spatial_aggregation"], nd),
                 "spatial_prediction": rlist(it["spatial_prediction"], nd)}
    }


def sample_pairs(num, nwin, nnodes, seed):
    rng = np.random.default_rng(seed); pairs = set(); total = nwin*nnodes; num = min(num, total)
    while len(pairs) < num:
        m = min(num-len(pairs), 10000)
        for i, j in zip(rng.integers(0, nwin, m), rng.integers(0, nnodes, m)): pairs.add((int(i), int(j)))
    return list(pairs)


def beta_search(builder, pairs):
    cache = []
    old = builder.beta
    for c, (i, n) in enumerate(pairs, 1):
        if c % 1000 == 0: print(f"[beta] precompute {c}/{len(pairs)}")
        builder.beta = 0.0; it = builder.item("train", i, n); cache.append((it["y_true"], it["pso_prediction"], it["spatial_aggregation"]))
    builder.beta = old
    rec = []
    for b in [round(x*0.1, 3) for x in range(11)]:
        e = []
        for y, p, s in cache:
            e.append(np.abs(nonneg((1-b)*p + b*s) - y).reshape(-1))
        mae = float(np.concatenate(e).mean()); rec.append({"beta": b, "MAE": mae}); print(f"[beta] {b:.1f} MAE={mae:.6f}")
    best = min(rec, key=lambda x: x["MAE"])
    return {"best": best, "records": rec}


def cmd_generate(args):
    seed_all(args.seed); out = Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    arr = load_arrays(Path(args.data_dir)); raw = np.loadtxt(args.raw_csv, delimiter=',', dtype=np.float32)
    print("[LOAD] raw", raw.shape)
    time_w, cand_w = load_pso(Path(args.pso_weights))
    ntr, _, nn = arr["X_train"].shape; nva = arr["X_val"].shape[0]
    if args.top_k < 1 or args.top_k >= nn:
        raise ValueError(f"top_k 必须介于1与节点数-1之间，当前 top_k={args.top_k}, nn={nn}")
    starts, train_end = load_window_starts(Path(args.data_dir), arr, raw)
    raw_train = raw[:train_end]  # 只包含训练X/Y范围
    prof = pso_core.build_time_of_day_profile(raw, train_end)
    if prof is None: raise ValueError("训练片段不足288个时步，原PSO无法构建合法日内画像")
    S = similarity(raw_train, args.similarity_method); np.save(out/"spatial_similarity.npy", S)
    topk = topk_from_sim(S, args.top_k)
    json.dump({str(k): [{"sensor_id": j, "similarity": s} for j,s in v] for k,v in topk.items()}, open(out/"topk_spatial_neighbors.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    beta = 0.0
    builder = Builder(raw, arr, time_w, cand_w, prof, topk, beta, args.tau, starts, train_end)
    if args.beta == "auto":
        pairs = sample_pairs(args.beta_search_pairs, ntr, nn, args.seed+99)
        br = beta_search(builder, pairs); json.dump(br, open(out/"spatial_beta_search_metrics.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
        beta = float(br["best"]["beta"]); print("[beta selected]", beta)
    else:
        beta = float(args.beta)
    builder.beta = beta
    cfg = {"architecture": "pso_topk_spatial_pre_correction_llm_lora", "spatial_enabled": True, "canonical_pso_candidates": True, "train_end_row_exclusive": train_end, "compact_prompt": bool(args.compact_prompt), "top_k": args.top_k, "similarity_method": args.similarity_method, "tau": args.tau, "beta": beta, "candidate_names": CANDIDATES, "candidate_weights": cand_w, "time_weights": rlist(time_w, 6)}
    json.dump(cfg, open(out/"spatial_config.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    train_pairs = sample_pairs(args.max_train_samples, ntr, nn, args.seed)
    val_pairs = sample_pairs(args.max_val_samples, nva, nn, args.seed+1)
    for split, pairs in [("train", train_pairs), ("val", val_pairs)]:
        with open(out/f"{split}_messages.jsonl", "w", encoding="utf-8") as f, open(out/f"{split}_sample_index.csv", "w", newline='', encoding="utf-8") as cf:
            cw = csv.writer(cf); cw.writerow(["sample_idx", "sensor_id"])
            for c, (i, n) in enumerate(pairs, 1):
                if c % 1000 == 0: print(f"[{split}] {c}/{len(pairs)}")
                cw.writerow([i, n])
                f.write(json.dumps(make_record(builder.item(split, i, n), args.round_ndigits, compact=bool(args.compact_prompt)), ensure_ascii=False)+"\n")
    # preview & stats
    with open(out/"train_messages.jsonl", encoding="utf-8") as f, open(out/"prompt_preview.jsonl", "w", encoding="utf-8") as pf:
        for _, line in zip(range(5), f): pf.write(line)
    stats = {"train_records": len(train_pairs), "val_records": len(val_pairs), "raw_shape": list(raw.shape), "train_end_row_exclusive": train_end, "X_train_shape": list(arr["X_train"].shape), "X_val_shape": list(arr["X_val"].shape), "spatial_similarity_shape": list(S.shape), "beta": beta, "architecture": "pso_topk_spatial_pre_correction_llm_lora", "spatial_enabled": True}
    json.dump(stats, open(out/"data_stats.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    print(json.dumps(stats, indent=2, ensure_ascii=False))

# ----------------- train/eval -----------------
def import_train_libs():
    global torch, Dataset, DataLoader, tqdm, AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig, LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel
    import torch
    from torch.utils.data import Dataset, DataLoader
    from tqdm import tqdm
    from transformers import AutoTokenizer, AutoModelForCausalLM
    try:
        from transformers import BitsAndBytesConfig
    except Exception:
        BitsAndBytesConfig = None
    from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel


def load_jsonl(path, limit=None):
    rows = []
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
                if limit and len(rows) >= limit: break
    print(f"[LOAD] {path}: {len(rows)}")
    return rows


def chat_text(tok, msgs, gen=False):
    if getattr(tok, "chat_template", None):
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=gen)
    s = "".join([f"<{m['role']}>\n{m['content']}\n" for m in msgs])
    return s + ("<assistant>\n" if gen else "")


class MsgDS:
    """只计算 assistant 的 loss；禁止悄悄截断真实数值标签。"""
    def __init__(self, rows, tok, max_len):
        self.rows, self.tok, self.max_len = rows, tok, max_len

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, i):
        r = self.rows[i]
        prefix_msgs = [m for m in r["messages"] if m["role"] != "assistant"]
        prefix = chat_text(self.tok, prefix_msgs, True)
        full = chat_text(self.tok, r["messages"], False)
        if not full.startswith(prefix):
            raise ValueError("聊天模板无法将 assistant 回复与提示词分隔，请检查 chat_template")
        suffix = full[len(prefix):]  # 包含原模板的回合结束标志，例如 <|eot_id|>
        prefix_ids = self.tok(prefix, add_special_tokens=False)["input_ids"]
        full_ids = self.tok(full, add_special_tokens=False)["input_ids"]
        # 统一tokenize整个chat，严格核实首段与推理时prefix编码完全一致。
        # 不能假设分别tokenize两个字符串的结果一定等于拼接后的编码。
        if full_ids[:len(prefix_ids)] != prefix_ids:
            raise ValueError("Tokenizer在assistant边界合并了token，训练prompt与推理编码不一致")
        answer_ids = full_ids[len(prefix_ids):]
        if not answer_ids:
            raise ValueError("assistant 标签为空")
        if len(full_ids) > self.max_len:
            raise ValueError(
                f"数据长度 {len(full_ids)} 超过 max_len={self.max_len}。"
                "请重新 generate（默认 --compact_prompt 1）或增大 max_len，"
                "不要截断真实标签。"
            )
        ids = full_ids
        labels = [-100] * len(prefix_ids) + answer_ids
        return {
            "input_ids": torch.tensor(ids, dtype=torch.long),
            "attention_mask": torch.ones(len(ids), dtype=torch.long),
            "labels": torch.tensor(labels, dtype=torch.long),
        }


class Collate:
    def __init__(self, tok): self.pad = tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id
    def __call__(self, batch):
        L = max(x["input_ids"].numel() for x in batch)
        def pad(x, val): return torch.cat([x, torch.full((L-x.numel(),), val, dtype=x.dtype)]) if x.numel()<L else x
        return {"input_ids": torch.stack([pad(x["input_ids"], self.pad) for x in batch]), "attention_mask": torch.stack([pad(x["attention_mask"], 0) for x in batch]), "labels": torch.stack([pad(x["labels"], -100) for x in batch])}


def y_true(r): return np.asarray(r.get("meta", {}).get("y_true") or json.loads(r["messages"][-1]["content"])["predicted_flow"], dtype=np.float32)
def fallback(r):
    m = r.get("meta", {})
    for k in ["spatial_prediction", "pso_prediction"]:
        if k in m and isinstance(m[k], list) and len(m[k]) == 12:
            a = np.asarray(m[k], dtype=np.float32)
            if np.isfinite(a).all() and np.all(a >= 0): return a
    return None


def parse_flow(txt, expected_sensor=None):
    """严格解析新生成内容，不准从提示词/散乱文本里抽取最后12个数字。"""
    try:
        obj = json.loads(txt.strip())
    except (TypeError, json.JSONDecodeError):
        return None
    if not isinstance(obj, dict):
        return None
    if set(obj) != {"sensor_id", "predicted_flow"}:
        return None
    if expected_sensor is not None and obj["sensor_id"] != f"sensor_{int(expected_sensor)}":
        return None
    a = obj["predicted_flow"]
    if not isinstance(a, list) or len(a) != 12:
        return None
    if any(isinstance(x, bool) or not isinstance(x, (int, float)) for x in a):
        return None
    if any(not math.isfinite(x) or x < 0 for x in a):
        return None
    # math.isfinite(1e40) 仍为真，但 float32 会溢出成 inf。
    if any(abs(float(x)) > float(np.finfo(np.float32).max) for x in a):
        return None
    return [float(x) for x in a]


def metrics(Y, P, psnr_peak=None):
    Y = np.asarray(Y, dtype=np.float64).reshape(-1); P = np.asarray(P, dtype=np.float64).reshape(-1)
    if Y.shape != P.shape or not len(Y) or len(Y) % 12 or not (np.isfinite(Y).all() and np.isfinite(P).all()):
        raise ValueError("MAE输入必须为相同shape、有限数值且长度为12的整数倍")
    e = P-Y
    mask = Y > 1e-3; yt, yp = Y.reshape(-1,12), P.reshape(-1,12)
    out = {"MAE": float(np.mean(np.abs(e))), "RMSE": float(np.sqrt(np.mean(e*e))), "Masked_MAE": float(np.mean(np.abs(e[mask]))) if mask.any() else float(np.mean(np.abs(e))), "Masked_RMSE": float(np.sqrt(np.mean(e[mask]*e[mask]))) if mask.any() else float(np.sqrt(np.mean(e*e))), "Masked_MAPE_percent": float(np.mean(np.abs(e[mask])/np.maximum(np.abs(Y[mask]),1e-3))*100) if mask.any() else 0.0, "Peak_MAE": float(np.mean(np.abs(np.max(yp,1)-np.max(yt,1))))}
    if psnr_peak is not None:
        if not math.isfinite(psnr_peak) or psnr_peak <= 0: raise ValueError("psnr_peak 必须为正有限数")
        mse = float(np.mean(e*e))
        out["PSNR_dB"] = float(10.0*math.log10((psnr_peak**2)/mse)) if mse > 0 else float("inf")
        out["PSNR_peak"] = float(psnr_peak)
    return out


def load_base_lora(args, train=True):
    dtype = torch.bfloat16 if args.bf16 else torch.float16
    tok = AutoTokenizer.from_pretrained(args.model_path, local_files_only=bool(args.local_files_only))
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    qconf = None
    if getattr(args, "load_in_4bit", 0):
        if BitsAndBytesConfig is None: raise RuntimeError("BitsAndBytesConfig不可用，请升级transformers")
        qconf = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=dtype, bnb_4bit_use_double_quant=True)
    model = AutoModelForCausalLM.from_pretrained(args.model_path, torch_dtype=dtype, device_map="auto", quantization_config=qconf, local_files_only=bool(args.local_files_only))
    if train:
        if getattr(args, "load_in_4bit", 0): model = prepare_model_for_kbit_training(model)
        if args.gradient_checkpointing: model.gradient_checkpointing_enable(); model.config.use_cache = False
        lc = LoraConfig(r=args.lora_r, lora_alpha=args.lora_alpha, target_modules=[x.strip() for x in args.target_modules.split(',') if x.strip()], lora_dropout=args.lora_dropout, bias="none", task_type="CAUSAL_LM")
        model = get_peft_model(model, lc); model.print_trainable_parameters()
    else:
        model = PeftModel.from_pretrained(model, args.lora_adapter, local_files_only=bool(args.local_files_only))
    return model, tok


def gen_one(model, tok, r, max_new):
    msgs = [m for m in r["messages"] if m["role"] != "assistant"]
    prompt = chat_text(tok, msgs, True)
    inp = tok(prompt, return_tensors="pt", add_special_tokens=False).to(model.device)
    input_len = inp["input_ids"].shape[1]
    eot_id = tok.convert_tokens_to_ids("<|eot_id|>")
    ends = [tok.eos_token_id]
    if isinstance(eot_id, int) and eot_id >= 0 and eot_id != tok.unk_token_id and eot_id not in ends:
        ends.append(eot_id)
    with torch.no_grad():
        generated = model.generate(**inp, max_new_tokens=max_new, do_sample=False,
                                   pad_token_id=tok.eos_token_id,
                                   eos_token_id=ends)
    # 修复：不能 decode 整个prompt后再按字符串长度截取。
    return tok.decode(generated[0][input_len:], skip_special_tokens=True).strip()


def evaluate(model, tok, rows, out_dir, max_new, fb_on=True):
    model.eval()
    all_y, all_production_p = [], []
    llm_y, llm_p = [], []
    ref_y, pso_p, spatial_p = [], [], []
    parse_fail, fb_count, recs = 0, 0, []
    for i, r in enumerate(tqdm(rows, desc="Strict LLM eval")):
        generated_text = gen_one(model, tok, r, max_new)
        y = y_true(r)
        if "sensor_id" not in r.get("meta", {}):
            raise ValueError("评测样本缺少目标 sensor_id 元数据，不能放宽ID校验")
        raw_prediction = parse_flow(generated_text, r["meta"]["sensor_id"])
        valid = raw_prediction is not None
        if valid:
            llm_y.append(y)
            llm_p.append(raw_prediction)
        else:
            parse_fail += 1
        fb = fallback(r) if fb_on else None
        production_p = np.asarray(raw_prediction, dtype=np.float32) if valid else fb
        use_fallback = not valid and fb is not None
        if use_fallback: fb_count += 1
        if production_p is not None:
            all_y.append(y)
            all_production_p.append(production_p)
        meta = r.get("meta", {})
        if all(key in meta for key in ["pso_prediction", "spatial_prediction"]):
            ref_y.append(y)
            pso_p.append(meta["pso_prediction"])
            spatial_p.append(meta["spatial_prediction"])
        recs.append({
            "idx": i, "sensor_id": meta.get("sensor_id", ""),
            "parse_ok": int(valid), "used_fallback": int(use_fallback),
            "raw_output": generated_text, "y_true": json.dumps(rlist(y), ensure_ascii=False),
            "llm_y_pred": json.dumps(raw_prediction, ensure_ascii=False) if valid else "",
            "final_y_pred": json.dumps(rlist(production_p), ensure_ascii=False) if production_p is not None else ""
        })

    n = len(rows)
    # 不允许在部分样本解析失败时仅评估成功样本并称之为全体MAE。
    llm_all_valid = len(llm_p) == n
    model_metrics = metrics(np.stack(llm_y), np.stack(llm_p)) if llm_all_valid and llm_p else None
    valid_subset_metrics = metrics(np.stack(llm_y), np.stack(llm_p)) if llm_p else None
    production_metrics = metrics(np.stack(all_y), np.stack(all_production_p)) if len(all_y) == n and all_y else None
    pso_metrics = metrics(np.stack(ref_y), np.stack(pso_p)) if len(ref_y) == n and ref_y else None
    spatial_metrics = metrics(np.stack(ref_y), np.stack(spatial_p)) if len(ref_y) == n and ref_y else None
    m = {
        "model_only_metrics_all_samples": model_metrics,
        "model_only_metrics_valid_subset_not_comparable": valid_subset_metrics,
        "production_metrics_with_fallback": production_metrics,
        "pso_baseline_metrics": pso_metrics,
        "spatial_baseline_metrics": spatial_metrics,
        "num_eval_samples": n,
        "num_valid_llm_predictions": len(llm_p),
        "parse_fail_count": parse_fail,
        "parse_fail_rate": parse_fail/max(1,n),
        "fallback_count": fb_count,
        "fallback_rate": fb_count/max(1,n),
        "model_mae_below_14": bool(model_metrics and model_metrics["MAE"] < 14),
        "claimable_model_MAE": model_metrics["MAE"] if model_metrics else None,
        "note": "模型的MAE仅在所有样本都合法时报告；fallback指标不能用作纯LLM指标。"
    }
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    (out/"spatial_llm_validation_metrics.json").write_text(json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")
    if recs:
        with open(out/"spatial_llm_validation_predictions.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(recs[0].keys())); w.writeheader(); w.writerows(recs)
    print(json.dumps(m, indent=2, ensure_ascii=False)); return m


def cmd_train(args):
    import_train_libs(); seed_all(args.seed); out=Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    train_rows = load_jsonl(args.train_file, args.max_train_records); val_rows = load_jsonl(args.val_file, args.max_val_records); eval_rows = val_rows[:min(args.max_generate_samples, len(val_rows))]
    model, tok = load_base_lora(args, train=True)
    ds = MsgDS(train_rows, tok, args.max_len); dl = DataLoader(ds, batch_size=args.batch_size, shuffle=True, collate_fn=Collate(tok))
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr, weight_decay=args.weight_decay)
    hist=[]; model.train(); opt.zero_grad(set_to_none=True); t0=time.time(); g=0
    for ep in range(1, args.epochs+1):
        losses=[]; pbar=tqdm(dl, desc=f"epoch {ep}/{args.epochs}")
        for step, batch in enumerate(pbar, 1):
            batch = {k:v.to(model.device) for k,v in batch.items()}
            # 最后不足grad_accum个batch时按实际累计数归一化。
            group_start = ((step - 1) // args.grad_accum) * args.grad_accum
            group_size = min(args.grad_accum, len(dl) - group_start)
            loss = model(**batch).loss / group_size
            loss.backward(); losses.append(float(loss.detach().cpu())*group_size)
            if step % args.grad_accum == 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm); opt.step(); opt.zero_grad(set_to_none=True); g += 1; pbar.set_postfix(loss=f"{np.mean(losses[-50:]):.4f}", g=g)
        if len(dl) % args.grad_accum:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.max_grad_norm)
            opt.step(); opt.zero_grad(set_to_none=True); g += 1
        hist.append({"epoch": ep, "loss": float(np.mean(losses)), "global_step": g})
        json.dump(hist, open(out/"lora_train_history.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    model.save_pretrained(out/"lora_adapter"); tok.save_pretrained(out/"lora_adapter")
    m = evaluate(model, tok, eval_rows, out, args.max_new_tokens, bool(args.fallback_on_parse_fail))
    final = {"method":"PSO + Top-K spatial pre-correction + LLM-LoRA final predicted_flow", "architecture": "pso_topk_spatial_pre_correction_llm_lora", "spatial_enabled": True, "metrics": m, "total_time_sec": round(time.time()-t0,2)}
    json.dump(final, open(out/"final_spatial_llm_result.json", "w", encoding="utf-8"), indent=2, ensure_ascii=False)


def cmd_eval(args):
    import_train_libs(); rows = load_jsonl(args.val_file, args.max_eval_samples); model, tok = load_base_lora(args, train=False); evaluate(model, tok, rows, args.out_dir, args.max_new_tokens, bool(args.fallback_on_parse_fail))


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate")
    g.add_argument("--data_dir", required=True); g.add_argument("--raw_csv", required=True); g.add_argument("--pso_weights", required=True); g.add_argument("--out_dir", required=True)
    g.add_argument("--top_k", type=int, default=5); g.add_argument("--similarity_method", default="pearson", choices=["pearson","cosine"]); g.add_argument("--tau", type=float, default=0.1); g.add_argument("--beta", default="auto"); g.add_argument("--beta_search_pairs", type=int, default=5000)
    g.add_argument("--compact_prompt", type=int, default=1); g.add_argument("--max_train_samples", type=int, default=100000); g.add_argument("--max_val_samples", type=int, default=20000); g.add_argument("--round_ndigits", type=int, default=3); g.add_argument("--seed", type=int, default=42); g.set_defaults(func=cmd_generate)
    t = sub.add_parser("train")
    t.add_argument("--model_path", required=True); t.add_argument("--train_file", required=True); t.add_argument("--val_file", required=True); t.add_argument("--out_dir", required=True)
    t.add_argument("--max_train_records", type=int, default=50000); t.add_argument("--max_val_records", type=int, default=5000); t.add_argument("--max_generate_samples", type=int, default=200)
    t.add_argument("--max_len", type=int, default=2048); t.add_argument("--load_in_4bit", type=int, default=1); t.add_argument("--bf16", type=int, default=1); t.add_argument("--gradient_checkpointing", type=int, default=1); t.add_argument("--local_files_only", type=int, default=1)
    t.add_argument("--lora_r", type=int, default=16); t.add_argument("--lora_alpha", type=int, default=32); t.add_argument("--lora_dropout", type=float, default=0.05); t.add_argument("--target_modules", default="q_proj,k_proj,v_proj,o_proj")
    t.add_argument("--batch_size", type=int, default=1); t.add_argument("--grad_accum", type=int, default=16); t.add_argument("--epochs", type=int, default=2); t.add_argument("--lr", type=float, default=2e-4); t.add_argument("--weight_decay", type=float, default=0.01); t.add_argument("--max_grad_norm", type=float, default=1.0); t.add_argument("--max_new_tokens", type=int, default=160); t.add_argument("--fallback_on_parse_fail", type=int, default=1); t.add_argument("--seed", type=int, default=42); t.set_defaults(func=cmd_train)
    e = sub.add_parser("eval")
    e.add_argument("--model_path", required=True); e.add_argument("--lora_adapter", required=True); e.add_argument("--val_file", required=True); e.add_argument("--out_dir", required=True); e.add_argument("--max_eval_samples", type=int, default=5000); e.add_argument("--max_new_tokens", type=int, default=160); e.add_argument("--bf16", type=int, default=1); e.add_argument("--local_files_only", type=int, default=1); e.add_argument("--fallback_on_parse_fail", type=int, default=1); e.set_defaults(func=cmd_eval)
    args = p.parse_args(); args.func(args)

if __name__ == "__main__": main()
