from pathlib import Path
import torch
import torch.nn as nn

N_SENSOR = 358
DAY_STEPS = 288
PRED_LEN = 12


class TemporalResidualBlock(nn.Module):
    def __init__(self, channels, kernel_size=3, dilation=1, dropout=0.1):
        super().__init__()
        pad = dilation * (kernel_size - 1) // 2
        self.net = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return x + self.net(x)


class TemporalResidualPredictor(nn.Module):
    def __init__(self, hidden=512, dropout=0.08,
                 sensor_emb_dim=32, tod_emb_dim=16, dow_emb_dim=4, step_emb_dim=8):
        super().__init__()
        self.sensor_emb = nn.Embedding(N_SENSOR, sensor_emb_dim)
        self.tod_emb = nn.Embedding(DAY_STEPS, tod_emb_dim)
        self.dow_emb = nn.Embedding(7, dow_emb_dim)
        self.step_emb = nn.Embedding(PRED_LEN, step_emb_dim)
        self.future_tod_emb = nn.Embedding(DAY_STEPS, tod_emb_dim)
        self.in_proj = nn.Conv1d(2, hidden, kernel_size=1)
        self.temporal_blocks = nn.Sequential(
            TemporalResidualBlock(hidden, dilation=1, dropout=dropout),
            TemporalResidualBlock(hidden, dilation=2, dropout=dropout),
            TemporalResidualBlock(hidden, dilation=4, dropout=dropout),
        )
        self.context_norm = nn.LayerNorm(hidden)
        dec_in = hidden + 1 + sensor_emb_dim + tod_emb_dim + dow_emb_dim + step_emb_dim + tod_emb_dim
        self.decoder = nn.Sequential(
            nn.Linear(dec_in, hidden), nn.LayerNorm(hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden // 2, 1),
        )

    def forward(self, hist_norm, diff_norm, pso_norm, sensor_ids, tod_ids, dow_ids):
        b = hist_norm.shape[0]
        x = torch.stack([hist_norm, diff_norm], dim=1)
        z = self.in_proj(x)
        z = self.temporal_blocks(z)
        context = self.context_norm(z.mean(dim=2) + z[:, :, -1])
        step_ids = torch.arange(PRED_LEN, device=hist_norm.device, dtype=torch.long)
        step_e = self.step_emb(step_ids).unsqueeze(0).expand(b, -1, -1)
        sensor_e = self.sensor_emb(sensor_ids)
        tod_e = self.tod_emb(tod_ids)
        dow_e = self.dow_emb(dow_ids)
        node_time_e = torch.cat([sensor_e, tod_e, dow_e], dim=1).unsqueeze(1).expand(-1, PRED_LEN, -1)
        future_tod = (tod_ids.unsqueeze(1) + step_ids.unsqueeze(0)) % DAY_STEPS
        future_tod_e = self.future_tod_emb(future_tod)
        context_e = context.unsqueeze(1).expand(-1, PRED_LEN, -1)
        pso_e = pso_norm.unsqueeze(-1)
        dec = torch.cat([context_e, pso_e, node_time_e, step_e, future_tod_e], dim=2)
        return self.decoder(dec).squeeze(-1)


def load_residual_checkpoint(path, device='cpu'):
    path = Path(path)
    ckpt = torch.load(path, map_location=device, weights_only=False)
    model = TemporalResidualPredictor(
        hidden=int(ckpt.get('hidden', 512)),
        dropout=float(ckpt.get('dropout', 0.08)),
        sensor_emb_dim=int(ckpt.get('sensor_emb_dim', 32)),
        tod_emb_dim=int(ckpt.get('tod_emb_dim', 16)),
        dow_emb_dim=int(ckpt.get('dow_emb_dim', 4)),
        step_emb_dim=int(ckpt.get('step_emb_dim', 8)),
    )
    model.load_state_dict(ckpt['model_state_dict'], strict=True)
    model.to(device).eval()
    return model, ckpt


if __name__ == '__main__':
    default = Path(__file__).resolve().parents[1] / 'model' / 'pretrained_residual_checkpoint.pth'
    model, ckpt = load_residual_checkpoint(default)
    print('checkpoint:', default)
    print('loaded:', type(model).__name__)
    print('best_epoch:', ckpt.get('best_epoch'))
    print('spatial_retrained:', ckpt.get('spatial_retrained'))
