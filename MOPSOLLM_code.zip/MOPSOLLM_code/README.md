# PeMS03 Traffic Flow Forecasting — PSO + Spatial Features + LLM-LoRA

## Project overview

- Dataset: PeMS03, 358 sensors, 5-minute measurements.
- Task: 12 historical steps -> 12 future steps.
- Workflow: PSO baseline -> Top-K spatial features -> LoRA fine-tuned Llama-3-8B predictions.
- Acceptance target: **MAE < 14** on a consistent independent test set. **This target has not been confirmed for the newly fine-tuned LLM.**

## Project layout

```text
pems03_pso_spatial_llm/
├── README.md
├── requirements.txt
├── run_pipeline.sh                   # main run entry (default: 2 epochs)
├── code/                             # existing Python algorithms; imports unchanged
├── scripts/prepare_dataset.py       # raw CSV -> 12-to-12 windows and time indices
├── tests/unit_check.py              # CPU consistency tests (requires PyTorch)
├── model/                            # saved PSO weights, legacy residual checkpoint
├── data/raw/PEMS-03.csv              # source data provided with the delivery
├── data/processed/                  # created at runtime
├── outputs/                         # created at runtime
├── reports/archive/                 # historical/unverified metrics, NOT new results
└── docs/
    ├── run_guide.md                 # step-by-step instructions
    ├── method.md                    # original technical specification
    ├── change_log.md                # repair history
    └── validation_notes.md          # technical validation notes
```

## Quick start (AutoDL / Linux)

1. Create a Python environment with PyTorch + CUDA and install the packages in `requirements.txt`.
2. Put your authorized **Meta-Llama-3-8B-Instruct** base model at `/root/autodl-tmp/models/Meta-Llama-3-8B-Instruct` or set `MODEL_PATH`.
3. Run the following from this project directory:

```bash
pip install -r requirements.txt
python tests/unit_check.py
# Very small integration run; still needs a compatible GPU and base model
TRAIN_SAMPLES=200 VAL_SAMPLES=20 EVAL_SAMPLES=20 EPOCHS=1 OUT_DIR=./outputs/smoke bash run_pipeline.sh
```


```

See [`docs/run_guide.md`](docs/run_guide.md) for data generation, output files, and standalone evaluation commands. `run_pipeline.sh` will prepare the 12-to-12 data on the first run if missing. The base Llama model is **not** bundled; the carried-forward residual checkpoint is not the newly trained spatial-LLM model.
