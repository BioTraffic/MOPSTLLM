#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="${PYTHON_BIN:-python}"
RAW_CSV="${RAW_CSV:-$ROOT/data/raw/PEMS-03.csv}"
DATA_DIR="${DATA_DIR:-$ROOT/data/processed/pems03_12to12}"
MODEL_PATH="${MODEL_PATH:-/root/autodl-tmp/models/Meta-Llama-3-8B-Instruct}"
OUT_DIR="${OUT_DIR:-$ROOT/outputs/default}"
TRAIN_SAMPLES="${TRAIN_SAMPLES:-50000}"
VAL_SAMPLES="${VAL_SAMPLES:-5000}"
EVAL_SAMPLES="${EVAL_SAMPLES:-200}"
EPOCHS="${EPOCHS:-2}"
if [[ ! -f "$RAW_CSV" ]]; then
  echo "Missing raw dataset: $RAW_CSV" >&2; exit 2
fi
if [[ ! -d "$MODEL_PATH" ]]; then
  echo "Missing base model directory: $MODEL_PATH" >&2; exit 2
fi
if [[ ! -f "$DATA_DIR/X_train.npy" || ! -f "$DATA_DIR/train_index.csv" || ! -f "$DATA_DIR/X_val.npy" || ! -f "$DATA_DIR/val_index.csv" ]]; then
  echo "[1/3] Preparing 12-to-12 windows"
  "$PYTHON_BIN" "$ROOT/scripts/prepare_dataset.py" --raw_csv "$RAW_CSV" --out_dir "$DATA_DIR"
fi
mkdir -p "$OUT_DIR"
echo "[2/3] Generating PSO and spatial training messages"
"$PYTHON_BIN" "$ROOT/code/spatial_llm_pipeline.py" generate \
  --data_dir "$DATA_DIR" --raw_csv "$RAW_CSV" \
  --pso_weights "$ROOT/model/pso_weights.json" \
  --out_dir "$OUT_DIR/messages" --beta auto \
  --max_train_samples "$TRAIN_SAMPLES" --max_val_samples "$VAL_SAMPLES"
echo "[3/3] Training and evaluating LoRA (${EPOCHS} epochs)"
"$PYTHON_BIN" -u "$ROOT/code/spatial_llm_pipeline.py" train \
  --model_path "$MODEL_PATH" \
  --train_file "$OUT_DIR/messages/train_messages.jsonl" \
  --val_file "$OUT_DIR/messages/val_messages.jsonl" \
  --out_dir "$OUT_DIR/lora" \
  --max_train_records "$TRAIN_SAMPLES" --max_val_records "$VAL_SAMPLES" \
  --max_generate_samples "$EVAL_SAMPLES" --epochs "$EPOCHS" \
  2>&1 | tee "$OUT_DIR/train.log"
echo "Outputs: $OUT_DIR"
